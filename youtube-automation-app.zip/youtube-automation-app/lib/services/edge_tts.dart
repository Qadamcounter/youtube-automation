import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:web_socket_channel/io.dart';

/// One selectable voice preset, mapped onto a real neural voice.
class VoicePreset {
  final String id;
  final String label;
  final String language; // display group: English / Urdu / Arabic / Hindi
  final String edgeName; // e.g. en-US-GuyNeural
  final String locale; // e.g. en-US
  final int ratePct; // prosody rate adjustment, e.g. -15
  final int pitchPct; // prosody pitch adjustment, e.g. -8
  final String googleTl; // fallback language code for Google TTS

  const VoicePreset({
    required this.id,
    required this.label,
    required this.language,
    required this.edgeName,
    required this.locale,
    this.ratePct = 0,
    this.pitchPct = 0,
    required this.googleTl,
  });
}

/// Stage 1 voice set. The full list of 30 presets is added in Stage 2;
/// these are real, distinct neural voices (Microsoft Edge TTS class).
const List<VoicePreset> kVoicePresets = [
  VoicePreset(
    id: 'en_male_narrator',
    label: 'Male Narrator',
    language: 'English',
    edgeName: 'en-US-GuyNeural',
    locale: 'en-US',
    googleTl: 'en',
  ),
  VoicePreset(
    id: 'en_grandpa',
    label: 'Grandpa',
    language: 'English',
    edgeName: 'en-US-ChristopherNeural',
    locale: 'en-US',
    ratePct: -15,
    pitchPct: -8,
    googleTl: 'en',
  ),
  VoicePreset(
    id: 'en_female_narrator',
    label: 'Female Narrator',
    language: 'English',
    edgeName: 'en-US-JennyNeural',
    locale: 'en-US',
    googleTl: 'en',
  ),
  VoicePreset(
    id: 'en_female_soft',
    label: 'Female Soft',
    language: 'English',
    edgeName: 'en-US-AriaNeural',
    locale: 'en-US',
    ratePct: -5,
    googleTl: 'en',
  ),
  VoicePreset(
    id: 'ur_male',
    label: 'Urdu Male',
    language: 'Urdu',
    edgeName: 'ur-PK-AsadNeural',
    locale: 'ur-PK',
    googleTl: 'ur',
  ),
  VoicePreset(
    id: 'ur_female',
    label: 'Urdu Female',
    language: 'Urdu',
    edgeName: 'ur-PK-UzmaNeural',
    locale: 'ur-PK',
    googleTl: 'ur',
  ),
  VoicePreset(
    id: 'ar_male',
    label: 'Arabic Male',
    language: 'Arabic',
    edgeName: 'ar-SA-HamedNeural',
    locale: 'ar-SA',
    googleTl: 'ar',
  ),
  VoicePreset(
    id: 'ar_female',
    label: 'Arabic Female',
    language: 'Arabic',
    edgeName: 'ar-EG-SalmaNeural',
    locale: 'ar-EG',
    googleTl: 'ar',
  ),
  VoicePreset(
    id: 'hi_male',
    label: 'Hindi Male',
    language: 'Hindi',
    edgeName: 'hi-IN-MadhurNeural',
    locale: 'hi-IN',
    googleTl: 'hi',
  ),
  VoicePreset(
    id: 'hi_female',
    label: 'Hindi Female',
    language: 'Hindi',
    edgeName: 'hi-IN-SwaraNeural',
    locale: 'hi-IN',
    googleTl: 'hi',
  ),
];

List<VoicePreset> voicesForLanguage(String language) =>
    kVoicePresets.where((v) => v.language == language).toList();

/// Text-to-speech using free neural voices.
/// Primary: Microsoft Edge TTS (WebSocket protocol, no key needed).
/// Fallback: Google Translate TTS endpoint (also free, no key).
class TtsService {
  static const String _edgeToken = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';

  static String _timestamp() =>
      DateTime.now().toUtc().toString().replaceAll(' ', 'T');

  static String _requestId() {
    final r = Random();
    const hex = '0123456789abcdef';
    return List.generate(32, (_) => hex[r.nextInt(16)]).join();
  }

  static String _escapeXml(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&apos;');

  static String _signedPct(int v) => v >= 0 ? '+$v%' : '$v%';

  /// Synthesise [text] with [voice] and write an MP3 to [outFile].
  /// Returns true on success.
  static Future<bool> speakToFile(
    VoicePreset voice,
    String text,
    File outFile,
  ) async {
    final clean = text.trim();
    if (clean.isEmpty) return false;
    try {
      final bytes = await _edgeSynth(voice, clean)
          .timeout(const Duration(seconds: 45));
      if (bytes.length > 500) {
        await outFile.writeAsBytes(bytes);
        return true;
      }
    } catch (_) {
      // fall through to the backup voice route
    }
    try {
      final bytes = await _googleSynth(voice, clean)
          .timeout(const Duration(seconds: 45));
      if (bytes.length > 500) {
        await outFile.writeAsBytes(bytes);
        return true;
      }
    } catch (_) {}
    return false;
  }

  static Future<Uint8List> _edgeSynth(VoicePreset voice, String text) async {
    final url = 'wss://speech.platform.bing.com/consumer/speech/synthesize/'
        'readaloud/edge/v1?TrustedClientToken=$_edgeToken';
    final channel = IOWebSocketChannel.connect(
      Uri.parse(url),
      headers: {
        'Origin': 'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold',
        'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
      },
    );

    final audio = BytesBuilder();
    var done = false;
    Object? streamError;

    final sub = channel.stream.listen(
      (message) {
        if (message is String) {
          if (message.contains('Path:turn.end')) {
            done = true;
          }
        } else if (message is List<int>) {
          // Binary message: 2-byte header length, header, then audio bytes.
          if (message.length > 2) {
            final headerLen = (message[0] << 8) | message[1];
            final start = 2 + headerLen;
            if (start < message.length) {
              final header =
                  utf8.decode(message.sublist(2, start), allowMalformed: true);
              if (header.contains('Path:audio')) {
                audio.add(message.sublist(start));
              }
            }
          }
        }
      },
      onError: (Object e) => streamError = e,
      onDone: () => done = true,
    );

    final config = 'X-Timestamp:${_timestamp()}\r\n'
        'Content-Type:application/json; charset=utf-8\r\n'
        'Path:speech.config\r\n\r\n'
        '{"context":{"synthesis":{"audio":{"metadataoptions":'
        '{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"false"},'
        '"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}';
    channel.sink.add(config);

    final ssml = "<speak version='1.0' "
        "xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='${voice.locale}'>"
        "<voice name='${voice.edgeName}'>"
        "<prosody pitch='${_signedPct(voice.pitchPct)}' "
        "rate='${_signedPct(voice.ratePct)}'>"
        '${_escapeXml(text)}</prosody></voice></speak>';
    final ssmlMsg = 'X-RequestId:${_requestId()}\r\n'
        'Content-Type:application/ssml+xml\r\n'
        'X-Timestamp:${_timestamp()}\r\n'
        'Path:ssml\r\n\r\n$ssml';
    channel.sink.add(ssmlMsg);

    final sw = Stopwatch()..start();
    while (!done && sw.elapsed < const Duration(seconds: 40)) {
      await Future<void>.delayed(const Duration(milliseconds: 100));
    }
    await sub.cancel();
    await channel.sink.close();
    if (streamError != null) {
      throw StateError('edge tts stream error');
    }
    final bytes = audio.toBytes();
    if (bytes.isEmpty) {
      throw StateError('edge tts returned no audio');
    }
    return bytes;
  }

  static Future<Uint8List> _googleSynth(VoicePreset voice, String text) async {
    // Split into <=180 char chunks on word boundaries.
    final chunks = <String>[];
    var rest = text;
    while (rest.length > 180) {
      var cut = rest.lastIndexOf(' ', 180);
      if (cut < 40) cut = 180;
      chunks.add(rest.substring(0, cut).trim());
      rest = rest.substring(cut).trim();
    }
    if (rest.isNotEmpty) chunks.add(rest);

    final out = BytesBuilder();
    for (final chunk in chunks) {
      final uri = Uri.https('translate.google.com', '/translate_tts', {
        'ie': 'UTF-8',
        'q': chunk,
        'tl': voice.googleTl,
        'client': 'tw-ob',
      });
      final resp = await http.get(uri, headers: {
        'User-Agent':
            'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
      });
      if (resp.statusCode == 200 && resp.bodyBytes.isNotEmpty) {
        out.add(resp.bodyBytes);
      } else {
        throw StateError('google tts http ${resp.statusCode}');
      }
    }
    return out.toBytes();
  }
}
