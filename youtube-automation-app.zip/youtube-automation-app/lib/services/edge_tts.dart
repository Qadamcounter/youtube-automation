import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:archive/archive.dart';
import 'package:sherpa_onnx/sherpa_onnx.dart' as sherpa;
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/io.dart';

/// One selectable voice preset, mapped onto a real neural voice.
class VoicePreset {
  final String id;
  final String label;
  final String language; // display group: English / Urdu / Arabic / Hindi
  final String edgeName; // e.g. en-US-GuyNeural
  final String locale; // e.g. en-US
  final int ratePct; // prosody rate adjustment, e.g. -15
  final int pitchPct; // prosody pitch adjustment, e.g. -8
  final String googleTl; // fallback language code for Google TTS

  /// Pitch factor for the OFFLINE (Piper) route only, layered on top
  /// of the preset's real Piper voice (see [piperVoice]). 1.0 = the
  /// natural voice; <1.0 sounds deeper/older, >1.0 younger/higher.
  /// Applied after synthesis with ffmpeg (asetrate + atempo), so each
  /// preset keeps a distinct character.
  final double piperPitch;

  /// Which bundled Piper model speaks this preset offline: one of
  /// 'ryan', 'danny', 'alan', 'joe' (male) or 'amy', 'kathleen',
  /// 'cori', 'jenny' (female) — the file is `<piperVoice>.onnx` in
  /// the extracted tts pack. Empty = the gender default
  /// (ryan / amy). Only used for English presets; the other
  /// languages have no offline models.
  final String piperVoice;

  /// Tokens file paired with [piperVoice]. Most models share
  /// 'tokens.txt', but the three medium models MUST use their own
  /// (cori_tokens.txt, joe_tokens.txt, jenny_tokens.txt) or their
  /// output garbles.
  final String piperTokens;

  const VoicePreset({
    required this.id,
    required this.label,
    required this.language,
    required this.edgeName,
    required this.locale,
    this.ratePct = 0,
    this.pitchPct = 0,
    required this.googleTl,
    this.piperPitch = 1.0,
    this.piperVoice = '',
    this.piperTokens = 'tokens.txt',
  });
}

/// The agreed list of 30 voice presets (Stage 2), each mapped onto a
/// real, distinct neural voice (Microsoft Edge TTS class) with its own
/// speed/pitch character. Urdu, Arabic and Hindi voices follow.
const List<VoicePreset> kVoicePresets = [
  VoicePreset(id: 'en_male_narrator', label: '01 Male Narrator', language: 'English', edgeName: 'en-US-GuyNeural', locale: 'en-US', googleTl: 'en', piperPitch: 1.00, piperVoice: 'joe', piperTokens: 'joe_tokens.txt'),
  VoicePreset(id: 'en_grandpa', label: '02 Grandpa', language: 'English', edgeName: 'en-US-ChristopherNeural', locale: 'en-US', ratePct: -15, pitchPct: -8, googleTl: 'en', piperPitch: 0.88, piperVoice: 'alan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_deep_serious', label: '03 Deep Serious', language: 'English', edgeName: 'en-GB-RyanNeural', locale: 'en-GB', ratePct: -8, pitchPct: -10, googleTl: 'en', piperPitch: 0.87, piperVoice: 'alan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_young_energetic', label: '04 Young Energetic', language: 'English', edgeName: 'en-AU-WilliamNeural', locale: 'en-AU', ratePct: 8, pitchPct: 4, googleTl: 'en', piperPitch: 1.08, piperVoice: 'danny', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_father_christmas', label: '05 Father Christmas', language: 'English', edgeName: 'en-GB-RyanNeural', locale: 'en-GB', ratePct: -18, pitchPct: -6, googleTl: 'en', piperPitch: 0.92, piperVoice: 'alan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_wealthy', label: '06 Wealthy Man', language: 'English', edgeName: 'en-GB-ThomasNeural', locale: 'en-GB', ratePct: -5, pitchPct: -4, googleTl: 'en', piperPitch: 0.93, piperVoice: 'alan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_warm_dad', label: '07 Warm Dad', language: 'English', edgeName: 'en-US-EricNeural', locale: 'en-US', ratePct: -5, googleTl: 'en', piperPitch: 0.97, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_warm_uncle', label: '08 Warm Uncle', language: 'English', edgeName: 'en-IN-PrabhatNeural', locale: 'en-IN', pitchPct: -2, googleTl: 'en', piperPitch: 0.98, piperVoice: 'alan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_gentle_man', label: '09 Gentle Man', language: 'English', edgeName: 'en-US-SteffanNeural', locale: 'en-US', ratePct: -8, pitchPct: 2, googleTl: 'en', piperPitch: 1.00, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_gentle_young', label: '10 Gentle Young Man', language: 'English', edgeName: 'en-US-RogerNeural', locale: 'en-US', ratePct: -2, pitchPct: 4, googleTl: 'en', piperPitch: 1.03, piperVoice: 'danny', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_yes_daddy', label: '11 Yes Daddy', language: 'English', edgeName: 'en-US-ChristopherNeural', locale: 'en-US', ratePct: 2, pitchPct: -6, googleTl: 'en', piperPitch: 0.95, piperVoice: 'joe', piperTokens: 'joe_tokens.txt'),
  VoicePreset(id: 'en_skilled', label: '12 Skilled', language: 'English', edgeName: 'en-US-EricNeural', locale: 'en-US', ratePct: 4, googleTl: 'en', piperPitch: 1.00, piperVoice: 'danny', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_authoritative', label: '13 Authoritative', language: 'English', edgeName: 'en-GB-RyanNeural', locale: 'en-GB', ratePct: -2, pitchPct: -8, googleTl: 'en', piperPitch: 0.90, piperVoice: 'joe', piperTokens: 'joe_tokens.txt'),
  VoicePreset(id: 'en_reliable', label: '14 Reliable', language: 'English', edgeName: 'en-US-SteffanNeural', locale: 'en-US', pitchPct: -2, googleTl: 'en', piperPitch: 0.98, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_rugged', label: '15 Rugged', language: 'English', edgeName: 'en-AU-WilliamNeural', locale: 'en-AU', ratePct: -6, pitchPct: -10, googleTl: 'en', piperPitch: 0.88, piperVoice: 'alan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_smooth', label: '16 Smooth', language: 'English', edgeName: 'en-US-GuyNeural', locale: 'en-US', ratePct: -4, pitchPct: 2, googleTl: 'en', piperPitch: 1.00, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_villain', label: '17 Villain Deep', language: 'English', edgeName: 'en-GB-ThomasNeural', locale: 'en-GB', ratePct: -12, pitchPct: -18, googleTl: 'en', piperPitch: 0.85, piperVoice: 'alan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_news', label: '18 News Anchor', language: 'English', edgeName: 'en-US-GuyNeural', locale: 'en-US', ratePct: 5, pitchPct: -2, googleTl: 'en', piperPitch: 0.97, piperVoice: 'joe', piperTokens: 'joe_tokens.txt'),
  VoicePreset(id: 'en_dramatic', label: '19 Dramatic Storyteller', language: 'English', edgeName: 'en-IN-PrabhatNeural', locale: 'en-IN', ratePct: -6, pitchPct: -4, googleTl: 'en', piperPitch: 0.93, piperVoice: 'joe', piperTokens: 'joe_tokens.txt'),
  VoicePreset(id: 'en_female_narrator', label: '20 Female Narrator', language: 'English', edgeName: 'en-US-JennyNeural', locale: 'en-US', googleTl: 'en', piperPitch: 1.02, piperVoice: 'cori', piperTokens: 'cori_tokens.txt'),
  VoicePreset(id: 'en_female_soft', label: '21 Female Soft', language: 'English', edgeName: 'en-US-AriaNeural', locale: 'en-US', ratePct: -6, pitchPct: 2, googleTl: 'en', piperPitch: 1.00, piperVoice: 'cori', piperTokens: 'cori_tokens.txt'),
  VoicePreset(id: 'en_female_cheerful', label: '22 Female Cheerful', language: 'English', edgeName: 'en-US-AnaNeural', locale: 'en-US', ratePct: 8, pitchPct: 6, googleTl: 'en', piperPitch: 1.10, piperVoice: 'jenny', piperTokens: 'jenny_tokens.txt'),
  VoicePreset(id: 'en_grandma', label: '23 Grandma', language: 'English', edgeName: 'en-GB-SoniaNeural', locale: 'en-GB', ratePct: -16, pitchPct: -4, googleTl: 'en', piperPitch: 0.93, piperVoice: 'kathleen', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_dream', label: '24 Dream', language: 'English', edgeName: 'en-US-MichelleNeural', locale: 'en-US', ratePct: -10, pitchPct: 4, googleTl: 'en', piperPitch: 1.05, piperVoice: 'jenny', piperTokens: 'jenny_tokens.txt'),
  VoicePreset(id: 'en_teacher', label: '25 Teacher', language: 'English', edgeName: 'en-IN-NeerjaNeural', locale: 'en-IN', googleTl: 'en', piperPitch: 1.00, piperVoice: 'cori', piperTokens: 'cori_tokens.txt'),
  VoicePreset(id: 'en_whisper', label: '26 Whisper', language: 'English', edgeName: 'en-US-AriaNeural', locale: 'en-US', ratePct: -20, pitchPct: 2, googleTl: 'en', piperPitch: 1.02, piperVoice: 'cori', piperTokens: 'cori_tokens.txt'),
  VoicePreset(id: 'en_cartoon_boy', label: '27 Cartoon Boy', language: 'English', edgeName: 'en-US-AnaNeural', locale: 'en-US', ratePct: 18, pitchPct: 14, googleTl: 'en', piperPitch: 1.22, piperVoice: 'danny', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_cartoon_girl', label: '28 Cartoon Girl', language: 'English', edgeName: 'en-GB-MaisieNeural', locale: 'en-GB', ratePct: 6, pitchPct: 8, googleTl: 'en', piperPitch: 1.18, piperVoice: 'jenny', piperTokens: 'jenny_tokens.txt'),
  VoicePreset(id: 'ur_male', label: '29 Urdu Male', language: 'Urdu', edgeName: 'ur-PK-AsadNeural', locale: 'ur-PK', googleTl: 'ur'),
  VoicePreset(id: 'ur_female', label: '30 Urdu Female', language: 'Urdu', edgeName: 'ur-PK-UzmaNeural', locale: 'ur-PK', googleTl: 'ur'),
  VoicePreset(id: 'ar_male', label: 'Arabic Male', language: 'Arabic', edgeName: 'ar-SA-HamedNeural', locale: 'ar-SA', googleTl: 'ar'),
  VoicePreset(id: 'ar_female', label: 'Arabic Female', language: 'Arabic', edgeName: 'ar-EG-SalmaNeural', locale: 'ar-EG', googleTl: 'ar'),
  VoicePreset(id: 'hi_male', label: 'Hindi Male', language: 'Hindi', edgeName: 'hi-IN-MadhurNeural', locale: 'hi-IN', googleTl: 'hi'),
  VoicePreset(id: 'hi_female', label: 'Hindi Female', language: 'Hindi', edgeName: 'hi-IN-SwaraNeural', locale: 'hi-IN', googleTl: 'hi'),
  // ---- More speakers (Stage 2 expansion) ----
  VoicePreset(id: 'en_ava', label: 'Ava · US Female', language: 'English', edgeName: 'en-US-AvaNeural', locale: 'en-US', googleTl: 'en', piperPitch: 1.03, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_andrew', label: 'Andrew · US Male', language: 'English', edgeName: 'en-US-AndrewNeural', locale: 'en-US', googleTl: 'en', piperPitch: 0.97, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_brian', label: 'Brian · US Male', language: 'English', edgeName: 'en-US-BrianNeural', locale: 'en-US', googleTl: 'en', piperPitch: 1.03, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_emma', label: 'Emma · US Female', language: 'English', edgeName: 'en-US-EmmaNeural', locale: 'en-US', googleTl: 'en', piperPitch: 1.06, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_libby', label: 'Libby · UK Female', language: 'English', edgeName: 'en-GB-LibbyNeural', locale: 'en-GB', googleTl: 'en', piperPitch: 1.02, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_mia', label: 'Mia · UK Female', language: 'English', edgeName: 'en-GB-MiaNeural', locale: 'en-GB', googleTl: 'en', piperPitch: 1.08, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_alfie', label: 'Alfie · UK Male', language: 'English', edgeName: 'en-GB-AlfieNeural', locale: 'en-GB', googleTl: 'en', piperPitch: 1.05, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_elliot', label: 'Elliot · UK Male', language: 'English', edgeName: 'en-GB-ElliotNeural', locale: 'en-GB', googleTl: 'en', piperPitch: 0.95, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_natasha', label: 'Natasha · AU Female', language: 'English', edgeName: 'en-AU-NatashaNeural', locale: 'en-AU', googleTl: 'en', piperPitch: 1.00, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_annette', label: 'Annette · AU Female', language: 'English', edgeName: 'en-AU-AnnetteNeural', locale: 'en-AU', googleTl: 'en', piperPitch: 1.05, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_ken', label: 'Ken · AU Male', language: 'English', edgeName: 'en-AU-KenNeural', locale: 'en-AU', googleTl: 'en', piperPitch: 1.00, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_tim', label: 'Tim · AU Male', language: 'English', edgeName: 'en-AU-TimNeural', locale: 'en-AU', googleTl: 'en', piperPitch: 1.06, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_clara', label: 'Clara · CA Female', language: 'English', edgeName: 'en-CA-ClaraNeural', locale: 'en-CA', googleTl: 'en', piperPitch: 1.04, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_liam', label: 'Liam · CA Male', language: 'English', edgeName: 'en-CA-LiamNeural', locale: 'en-CA', googleTl: 'en', piperPitch: 0.98, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_emily', label: 'Emily · IE Female', language: 'English', edgeName: 'en-IE-EmilyNeural', locale: 'en-IE', googleTl: 'en', piperPitch: 1.07, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_connor', label: 'Connor · IE Male', language: 'English', edgeName: 'en-IE-ConnorNeural', locale: 'en-IE', googleTl: 'en', piperPitch: 1.02, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_molly', label: 'Molly · NZ Female', language: 'English', edgeName: 'en-NZ-MollyNeural', locale: 'en-NZ', googleTl: 'en', piperPitch: 1.01, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_mitchell', label: 'Mitchell · NZ Male', language: 'English', edgeName: 'en-NZ-MitchellNeural', locale: 'en-NZ', googleTl: 'en', piperPitch: 1.04, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_leah', label: 'Leah · ZA Female', language: 'English', edgeName: 'en-ZA-LeahNeural', locale: 'en-ZA', googleTl: 'en', piperPitch: 0.99, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_luke', label: 'Luke · ZA Male', language: 'English', edgeName: 'en-ZA-LukeNeural', locale: 'en-ZA', googleTl: 'en', piperPitch: 0.96, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_aarav', label: 'Aarav · IN Male', language: 'English', edgeName: 'en-IN-AaravNeural', locale: 'en-IN', googleTl: 'en', piperPitch: 1.01, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_aashi', label: 'Aashi · IN Female', language: 'English', edgeName: 'en-IN-AashiNeural', locale: 'en-IN', googleTl: 'en', piperPitch: 1.05, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_kavita_en', label: 'Kavita · IN Female', language: 'English', edgeName: 'en-IN-KavitaNeural', locale: 'en-IN', googleTl: 'en', piperPitch: 1.02, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_arjun', label: 'Arjun · IN Male', language: 'English', edgeName: 'en-IN-ArjunNeural', locale: 'en-IN', googleTl: 'en', piperPitch: 0.99, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_luna', label: 'Luna · SG Female', language: 'English', edgeName: 'en-SG-LunaNeural', locale: 'en-SG', googleTl: 'en', piperPitch: 1.06, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_wayne', label: 'Wayne · SG Male', language: 'English', edgeName: 'en-SG-WayneNeural', locale: 'en-SG', googleTl: 'en', piperPitch: 1.00, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_rosa', label: 'Rosa · PH Female', language: 'English', edgeName: 'en-PH-RosaNeural', locale: 'en-PH', googleTl: 'en', piperPitch: 1.03, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_james', label: 'James · PH Male', language: 'English', edgeName: 'en-PH-JamesNeural', locale: 'en-PH', googleTl: 'en', piperPitch: 1.02, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_asilia', label: 'Asilia · KE Female', language: 'English', edgeName: 'en-KE-AsiliaNeural', locale: 'en-KE', googleTl: 'en', piperPitch: 1.04, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_ezinne', label: 'Ezinne · NG Female', language: 'English', edgeName: 'en-NG-EzinneNeural', locale: 'en-NG', googleTl: 'en', piperPitch: 1.01, piperVoice: 'amy', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'en_abeo', label: 'Abeo · NG Male', language: 'English', edgeName: 'en-NG-AbeoNeural', locale: 'en-NG', googleTl: 'en', piperPitch: 0.97, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'ar_zariyah', label: 'Zariyah · SA Female', language: 'Arabic', edgeName: 'ar-SA-ZariyahNeural', locale: 'ar-SA', googleTl: 'ar'),
  VoicePreset(id: 'ar_shakir', label: 'Shakir · EG Male', language: 'Arabic', edgeName: 'ar-EG-ShakirNeural', locale: 'ar-EG', googleTl: 'ar'),
  VoicePreset(id: 'ar_fatima', label: 'Fatima · AE Female', language: 'Arabic', edgeName: 'ar-AE-FatimaNeural', locale: 'ar-AE', googleTl: 'ar'),
  VoicePreset(id: 'ar_hamdan', label: 'Hamdan · AE Male', language: 'Arabic', edgeName: 'ar-AE-HamdanNeural', locale: 'ar-AE', googleTl: 'ar'),
  VoicePreset(id: 'ar_laila', label: 'Laila · BH Female', language: 'Arabic', edgeName: 'ar-BH-LailaNeural', locale: 'ar-BH', googleTl: 'ar'),
  VoicePreset(id: 'ar_ali', label: 'Ali · BH Male', language: 'Arabic', edgeName: 'ar-BH-AliNeural', locale: 'ar-BH', googleTl: 'ar'),
  VoicePreset(id: 'ar_sana', label: 'Sana · JO Female', language: 'Arabic', edgeName: 'ar-JO-SanaNeural', locale: 'ar-JO', googleTl: 'ar'),
  VoicePreset(id: 'ar_taim', label: 'Taim · JO Male', language: 'Arabic', edgeName: 'ar-JO-TaimNeural', locale: 'ar-JO', googleTl: 'ar'),
  VoicePreset(id: 'ar_noura', label: 'Noura · KW Female', language: 'Arabic', edgeName: 'ar-KW-NouraNeural', locale: 'ar-KW', googleTl: 'ar'),
  VoicePreset(id: 'ar_fahed', label: 'Fahed · KW Male', language: 'Arabic', edgeName: 'ar-KW-FahedNeural', locale: 'ar-KW', googleTl: 'ar'),
  VoicePreset(id: 'ar_moza', label: 'Moza · QA Female', language: 'Arabic', edgeName: 'ar-QA-MozaNeural', locale: 'ar-QA', googleTl: 'ar'),
  VoicePreset(id: 'ar_mouna', label: 'Mouna · MA Female', language: 'Arabic', edgeName: 'ar-MA-MounaNeural', locale: 'ar-MA', googleTl: 'ar'),
  VoicePreset(id: 'ar_jamal', label: 'Jamal · MA Male', language: 'Arabic', edgeName: 'ar-MA-JamalNeural', locale: 'ar-MA', googleTl: 'ar'),
  VoicePreset(id: 'hi_aarav', label: 'Aarav · IN Male', language: 'Hindi', edgeName: 'hi-IN-AaravNeural', locale: 'hi-IN', googleTl: 'hi'),
  VoicePreset(id: 'hi_kavita', label: 'Kavita · IN Female', language: 'Hindi', edgeName: 'hi-IN-KavitaNeural', locale: 'hi-IN', googleTl: 'hi'),
  VoicePreset(id: 'hi_aarti', label: 'Aarti · IN Female', language: 'Hindi', edgeName: 'hi-IN-AartiNeural', locale: 'hi-IN', googleTl: 'hi'),
  // ---- CapCut-style character voices (same names/styles, own neural voices) ----
  VoicePreset(id: 'cc_storyteller_deep', label: 'Storyteller Deep', language: 'English', edgeName: 'en-GB-RyanNeural', locale: 'en-GB', ratePct: -12, pitchPct: -12, googleTl: 'en', piperPitch: 0.87, piperVoice: 'alan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'cc_documentary', label: 'Documentary Narrator', language: 'English', edgeName: 'en-US-ChristopherNeural', locale: 'en-US', ratePct: -4, pitchPct: -4, googleTl: 'en', piperPitch: 0.90, piperVoice: 'joe', piperTokens: 'joe_tokens.txt'),
  VoicePreset(id: 'cc_radio_host', label: 'Radio Host', language: 'English', edgeName: 'en-US-GuyNeural', locale: 'en-US', ratePct: 6, pitchPct: 2, googleTl: 'en', piperPitch: 1.03, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'cc_podcast_host', label: 'Podcast Host', language: 'English', edgeName: 'en-US-EricNeural', locale: 'en-US', ratePct: 2, pitchPct: 2, googleTl: 'en', piperPitch: 1.00, piperVoice: 'ryan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'cc_audiobook_female', label: 'Audiobook Female', language: 'English', edgeName: 'en-GB-SoniaNeural', locale: 'en-GB', ratePct: -4, googleTl: 'en', piperPitch: 0.98, piperVoice: 'cori', piperTokens: 'cori_tokens.txt'),
  VoicePreset(id: 'cc_cute_girl', label: 'Cute Girl', language: 'English', edgeName: 'en-GB-MaisieNeural', locale: 'en-GB', ratePct: 14, pitchPct: 16, googleTl: 'en', piperPitch: 1.20, piperVoice: 'jenny', piperTokens: 'jenny_tokens.txt'),
  VoicePreset(id: 'cc_anime_girl', label: 'Anime Girl', language: 'English', edgeName: 'en-US-AnaNeural', locale: 'en-US', ratePct: 24, pitchPct: 20, googleTl: 'en', piperPitch: 1.26, piperVoice: 'jenny', piperTokens: 'jenny_tokens.txt'),
  VoicePreset(id: 'cc_pirate', label: 'Pirate', language: 'English', edgeName: 'en-GB-RyanNeural', locale: 'en-GB', ratePct: -6, pitchPct: -14, googleTl: 'en', piperPitch: 0.88, piperVoice: 'alan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'cc_ghost', label: 'Ghost', language: 'English', edgeName: 'en-US-SteffanNeural', locale: 'en-US', ratePct: -22, pitchPct: -16, googleTl: 'en', piperPitch: 0.86, piperVoice: 'alan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'cc_witch', label: 'Witch', language: 'English', edgeName: 'en-GB-SoniaNeural', locale: 'en-GB', ratePct: -6, pitchPct: 10, googleTl: 'en', piperPitch: 1.08, piperVoice: 'kathleen', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'cc_vampire', label: 'Vampire', language: 'English', edgeName: 'en-GB-ThomasNeural', locale: 'en-GB', ratePct: -16, pitchPct: -14, googleTl: 'en', piperPitch: 0.86, piperVoice: 'alan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'cc_superhero', label: 'Superhero', language: 'English', edgeName: 'en-US-GuyNeural', locale: 'en-US', ratePct: 4, pitchPct: -10, googleTl: 'en', piperPitch: 0.92, piperVoice: 'joe', piperTokens: 'joe_tokens.txt'),
  VoicePreset(id: 'cc_princess', label: 'Princess', language: 'English', edgeName: 'en-GB-MaisieNeural', locale: 'en-GB', ratePct: 8, pitchPct: 10, googleTl: 'en', piperPitch: 1.14, piperVoice: 'jenny', piperTokens: 'jenny_tokens.txt'),
  VoicePreset(id: 'cc_wizard', label: 'Old Wizard', language: 'English', edgeName: 'en-GB-RyanNeural', locale: 'en-GB', ratePct: -20, pitchPct: -10, googleTl: 'en', piperPitch: 0.85, piperVoice: 'alan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'cc_meditation', label: 'Meditation Calm', language: 'English', edgeName: 'en-US-AriaNeural', locale: 'en-US', ratePct: -24, pitchPct: -2, googleTl: 'en', piperPitch: 0.97, piperVoice: 'cori', piperTokens: 'cori_tokens.txt'),
  VoicePreset(id: 'cc_asmr', label: 'ASMR Soft', language: 'English', edgeName: 'en-US-JennyNeural', locale: 'en-US', ratePct: -22, pitchPct: 2, googleTl: 'en', piperPitch: 1.03, piperVoice: 'cori', piperTokens: 'cori_tokens.txt'),
  VoicePreset(id: 'cc_commentator', label: 'Sports Commentator', language: 'English', edgeName: 'en-AU-KenNeural', locale: 'en-AU', ratePct: 12, googleTl: 'en', piperPitch: 1.05, piperVoice: 'danny', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'cc_trailer', label: 'Movie Trailer', language: 'English', edgeName: 'en-US-ChristopherNeural', locale: 'en-US', ratePct: -10, pitchPct: -16, googleTl: 'en', piperPitch: 0.85, piperVoice: 'alan', piperTokens: 'tokens.txt'),
  VoicePreset(id: 'cc_villainess', label: 'Villainess', language: 'English', edgeName: 'en-GB-SoniaNeural', locale: 'en-GB', ratePct: -6, pitchPct: -8, googleTl: 'en', piperPitch: 0.93, piperVoice: 'kathleen', piperTokens: 'tokens.txt'),
];

List<VoicePreset> voicesForLanguage(String language) =>
    kVoicePresets.where((v) => v.language == language).toList();

/// Text-to-speech using free neural voices.
/// Primary: Microsoft Edge TTS (WebSocket protocol, no key needed).
/// Fallback: Google Translate TTS endpoint (also free, no key).
class TtsService {
  static const String _edgeToken = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
  static const String _gecVersion = '2-143.0.3650.75';

  /// Which engine produced the most recent clip ('Neural' = Edge,
  /// 'TikTok' = TikTok voices, 'Device' = phone speech engine,
  /// 'Backup' = Google web voice).
  static String lastEngine = '';

  /// Short note about the most recent failure, shown on the result
  /// screen so problems can be diagnosed from a screenshot.
  static String lastError = '';

  static int _skewSec = 0;
  static bool _skewFetched = false;

  /// Microsoft checks the token against ITS clock; if the phone clock
  /// is off, every connection is refused (HTTP 403). Learn the offset
  /// once from the server's own Date header and correct for it.
  static Future<void> _fetchSkew() async {
    if (_skewFetched) return;
    _skewFetched = true;
    try {
      final resp = await http.get(
        Uri.parse('https://speech.platform.bing.com/consumer/speech/'
            'synthesize/readaloud/voices/list'
            '?trustedclienttoken=$_edgeToken'),
        headers: {'User-Agent': 'Mozilla/5.0'},
      ).timeout(const Duration(seconds: 10));
      final dateStr = resp.headers['date'];
      if (dateStr != null) {
        final server = HttpDate.parse(dateStr).toUtc();
        _skewSec = server.difference(DateTime.now().toUtc()).inSeconds;
      }
    } catch (_) {}
  }

  /// Microsoft now expects a Sec-MS-GEC token on the Edge TTS endpoint:
  /// SHA-256 of (current time in Windows file-time ticks, rounded down
  /// to 300 s, concatenated with the trusted client token), upper hex.
  static String _secMsGec() {
    final nowSec =
        DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000 + _skewSec;
    final rounded = nowSec - (nowSec % 300);
    final ticks = (rounded + 11644473600) * 10000000;
    return sha256
        .convert(utf8.encode('$ticks$_edgeToken'))
        .toString()
        .toUpperCase();
  }

  static String _randomHex32() {
    final r = Random.secure();
    return List.generate(32, (_) => '0123456789ABCDEF'[r.nextInt(16)])
        .join();
  }

  static String _timestamp() =>
      DateTime.now().toUtc().toString().replaceAll(' ', 'T');

  static String _requestId() {
    final r = Random();
    const hex = '0123456789abcdef';
    return List.generate(32, (_) => hex[r.nextInt(16)]).join();
  }

  static String _escapeXml(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&apos;');

  static String _signedPct(int v) => v >= 0 ? '+$v%' : '$v%';

  /// Synthesise [text] with [voice] and write an MP3 to [outFile].
  /// Returns true on success.
  static Future<bool> speakToFile(
    VoicePreset voice,
    String text,
    File outFile,
  ) async {
    final clean = text.trim();
    if (clean.isEmpty) return false;
    lastError = '';
    // First route for English: the offline Piper voices bundled in
    // the app — no server or network can block them.
    if (voice.locale.toLowerCase().startsWith('en')) {
      try {
        final okPiper = await _piperSynth(voice, clean, outFile)
            .timeout(const Duration(seconds: 240));
        if (okPiper) {
          lastEngine = 'Offline';
          lastError = '';
          return true;
        }
        lastError = 'offline: $_piperNote';
      } catch (e) {
        lastError = 'offline: $e';
      }
    }
    try {
      final bytes = await _edgeSynth(voice, clean)
          .timeout(const Duration(seconds: 45));
      if (bytes.length > 500) {
        await outFile.writeAsBytes(bytes);
        lastEngine = 'Neural';
        lastError = '';
        return true;
      }
      lastError = '$lastError | neural: empty audio';
    } catch (e) {
      lastError = '$lastError | neural: $e';
    }
    // Second natural-voice route (TikTok voices, plain HTTPS, no key):
    // a different male/female voice per preset.
    final tiktok = _tiktokVoiceFor(voice);
    if (tiktok != null) {
      try {
        final bytes = await _tiktokSynth(tiktok, clean)
            .timeout(const Duration(seconds: 45));
        if (bytes.length > 500) {
          await outFile.writeAsBytes(bytes);
          lastEngine = 'TikTok';
          return true;
        }
      } catch (e) {
        lastError = '$lastError | tiktok: $e';
      }
    }
    // Third route: the phone's own speech engine (Google TTS on the
    // device) — no server can refuse it, and each preset picks a
    // different device voice, male for male presets where available.
    try {
      final okDevice = await _deviceSynth(voice, clean, outFile)
          .timeout(const Duration(seconds: 90));
      if (okDevice) {
        lastEngine = 'Device';
        return true;
      }
      lastError = '$lastError | device: $_deviceNote';
    } catch (e) {
      lastError = '$lastError | device: $e';
    }
    try {
      final bytes = await _googleSynth(voice, clean)
          .timeout(const Duration(seconds: 45));
      if (bytes.length > 500) {
        await outFile.writeAsBytes(bytes);
        lastEngine = 'Backup';
        return true;
      }
    } catch (e) {
      lastError = '$lastError | backup: $e';
    }
    return false;
  }

  static Future<Uint8List> _edgeSynth(VoicePreset voice, String text) async {
    await _fetchSkew();
    final url = 'wss://speech.platform.bing.com/consumer/speech/synthesize/'
        'readaloud/edge/v1?TrustedClientToken=$_edgeToken'
        '&ConnectionId=${_randomHex32().toLowerCase()}'
        '&Sec-MS-GEC=${_secMsGec()}&Sec-MS-GEC-Version=$_gecVersion';
    final channel = IOWebSocketChannel.connect(
      Uri.parse(url),
      headers: {
        'Cookie': 'muid=${_randomHex32()};',
        'Origin': 'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold',
        'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 '
                'Edg/143.0.0.0',
        'Accept-Language': 'en-US,en;q=0.9',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
      },
    );
    await channel.ready.timeout(const Duration(seconds: 15));

    final audio = BytesBuilder();
    var done = false;
    Object? streamError;

    final sub = channel.stream.listen(
      (message) {
        if (message is String) {
          if (message.contains('Path:turn.end')) {
            done = true;
          }
        } else if (message is List<int>) {
          // Binary message: 2-byte header length, header, then audio bytes.
          if (message.length > 2) {
            final headerLen = (message[0] << 8) | message[1];
            final start = 2 + headerLen;
            if (start < message.length) {
              final header =
                  utf8.decode(message.sublist(2, start), allowMalformed: true);
              if (header.contains('Path:audio')) {
                audio.add(message.sublist(start));
              }
            }
          }
        }
      },
      onError: (Object e) => streamError = e,
      onDone: () => done = true,
    );

    final config = 'X-Timestamp:${_timestamp()}\r\n'
        'Content-Type:application/json; charset=utf-8\r\n'
        'Path:speech.config\r\n\r\n'
        '{"context":{"synthesis":{"audio":{"metadataoptions":'
        '{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"false"},'
        '"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}';
    channel.sink.add(config);

    final ssml = "<speak version='1.0' "
        "xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='${voice.locale}'>"
        "<voice name='${voice.edgeName}'>"
        "<prosody pitch='${_signedPct(voice.pitchPct)}' "
        "rate='${_signedPct(voice.ratePct)}'>"
        '${_escapeXml(text)}</prosody></voice></speak>';
    final ssmlMsg = 'X-RequestId:${_requestId()}\r\n'
        'Content-Type:application/ssml+xml\r\n'
        'X-Timestamp:${_timestamp()}\r\n'
        'Path:ssml\r\n\r\n$ssml';
    channel.sink.add(ssmlMsg);

    final sw = Stopwatch()..start();
    while (!done && sw.elapsed < const Duration(seconds: 40)) {
      await Future<void>.delayed(const Duration(milliseconds: 100));
    }
    await sub.cancel();
    await channel.sink.close();
    if (streamError != null) {
      throw StateError('edge tts stream error');
    }
    final bytes = audio.toBytes();
    if (bytes.isEmpty) {
      throw StateError('edge tts returned no audio');
    }
    return bytes;
  }

  static Future<Uint8List> _googleSynth(VoicePreset voice, String text) async {
    // Split into <=180 char chunks on word boundaries.
    final chunks = <String>[];
    var rest = text;
    while (rest.length > 180) {
      var cut = rest.lastIndexOf(' ', 180);
      if (cut < 40) cut = 180;
      chunks.add(rest.substring(0, cut).trim());
      rest = rest.substring(cut).trim();
    }
    if (rest.isNotEmpty) chunks.add(rest);

    final out = BytesBuilder();
    for (final chunk in chunks) {
      final uri = Uri.https('translate.google.com', '/translate_tts', {
        'ie': 'UTF-8',
        'q': chunk,
        'tl': voice.googleTl,
        'client': 'tw-ob',
      });
      final resp = await http.get(uri, headers: {
        'User-Agent':
            'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
      });
      if (resp.statusCode == 200 && resp.bodyBytes.isNotEmpty) {
        out.add(resp.bodyBytes);
      } else {
        throw StateError('google tts http ${resp.statusCode}');
      }
    }
    return out.toBytes();
  }

  // ---------- TikTok voices route ----------

  static const Set<String> _maleEdgeNames = {
    'en-US-GuyNeural', 'en-US-ChristopherNeural', 'en-GB-RyanNeural',
    'en-AU-WilliamNeural', 'en-GB-ThomasNeural', 'en-US-EricNeural',
    'en-IN-PrabhatNeural', 'en-US-SteffanNeural', 'en-US-RogerNeural',
    'en-AU-KenNeural', 'en-AU-TimNeural', 'en-CA-LiamNeural',
    'en-IE-ConnorNeural', 'en-NZ-MitchellNeural', 'en-ZA-LukeNeural',
    'en-IN-AaravNeural', 'en-IN-ArjunNeural', 'en-SG-WayneNeural',
    'en-PH-JamesNeural', 'en-NG-AbeoNeural', 'en-US-AndrewNeural',
    'en-US-BrianNeural', 'en-GB-AlfieNeural', 'en-GB-ElliotNeural',
  };
  static const List<String> _tiktokMale = [
    'en_us_006', 'en_us_007', 'en_us_009', 'en_us_010',
    'en_uk_001', 'en_au_002',
  ];
  static const List<String> _tiktokFemale = [
    'en_us_001', 'en_us_002', 'en_uk_003', 'en_au_001',
  ];

  /// Map a preset onto a distinct TikTok voice (English presets only).
  static String? _tiktokVoiceFor(VoicePreset preset) {
    if (preset.language != 'English') return null;
    final male = _maleEdgeNames.contains(preset.edgeName);
    final list = male ? _tiktokMale : _tiktokFemale;
    final idx = preset.id.hashCode.abs() % list.length;
    return list[idx];
  }

  static Future<Uint8List> _tiktokSynth(String tiktokVoice, String text) async {
    final chunks = <String>[];
    var rest = text;
    while (rest.length > 280) {
      var cut = rest.lastIndexOf('. ', 280);
      if (cut < 60) cut = rest.lastIndexOf(' ', 280);
      if (cut < 60) cut = 280;
      chunks.add(rest.substring(0, cut).trim());
      rest = rest.substring(cut).trim();
    }
    if (rest.isNotEmpty) chunks.add(rest);

    final out = BytesBuilder();
    for (final chunk in chunks) {
      final resp = await http.post(
        Uri.parse('https://tiktok-tts.weilnet.workers.dev/api/generation'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': chunk, 'voice': tiktokVoice}),
      );
      if (resp.statusCode != 200) {
        throw StateError('tiktok http ${resp.statusCode}');
      }
      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      final b64 = data['data'];
      if (data['success'] != true || b64 is! String || b64.isEmpty) {
        throw StateError('tiktok returned no audio');
      }
      out.add(base64Decode(b64));
    }
    final bytes = out.toBytes();
    if (bytes.isEmpty) throw StateError('tiktok returned no audio');
    return bytes;
  }

  // ---------- On-device speech engine route ----------

  static FlutterTts? _deviceTts;
  static String _deviceNote = 'not tried';

  static Future<bool> _deviceSynth(
      VoicePreset preset, String text, File outFile) async {
    final tts = _deviceTts ??= FlutterTts();
    try {
      final raw = await tts.getVoices;
      if (raw is List) {
        final loc = preset.locale.toLowerCase();
        final lang = loc.split('-').first;
        final matches = <Map>[];
        for (final v in raw) {
          if (v is Map) {
            final l = '${v['locale'] ?? ''}'.toLowerCase();
            if (l == loc || l.startsWith('$lang-') || l == lang) {
              matches.add(v);
            }
          }
        }
        Map? chosen;
        final male = _maleEdgeNames.contains(preset.edgeName);
        for (final v in matches) {
          final name = '${v['name'] ?? ''}'.toLowerCase();
          if (male && name.contains('#male')) {
            chosen = v;
            break;
          }
          if (!male && name.contains('#female')) {
            chosen = v;
            break;
          }
        }
        if (chosen == null) {
          for (final v in matches) {
            final name = '${v['name'] ?? ''}'.toLowerCase();
            if (male &&
                name.contains('male') &&
                !name.contains('female')) {
              chosen = v;
              break;
            }
            if (!male && name.contains('female')) {
              chosen = v;
              break;
            }
          }
        }
        chosen ??= matches.isEmpty
            ? null
            : matches[preset.id.hashCode.abs() % matches.length];
        if (chosen != null) {
          await tts.setVoice({
            'name': '${chosen['name']}',
            'locale': '${chosen['locale']}',
          });
        } else {
          await tts.setLanguage(preset.locale);
        }
      }
    } catch (_) {
      try {
        await tts.setLanguage(preset.locale);
      } catch (_) {}
    }
    await tts.setSpeechRate(
        (0.5 * (1 + preset.ratePct / 100)).clamp(0.1, 1.0).toDouble());
    await tts
        .setPitch((1.0 + preset.pitchPct / 100).clamp(0.5, 2.0).toDouble());

    // Android TTS caps one utterance; split long scenes and merge.
    final chunks = <String>[];
    var rest = text;
    while (rest.length > 900) {
      var cut = rest.lastIndexOf('. ', 900);
      if (cut < 200) cut = rest.lastIndexOf(' ', 900);
      if (cut < 200) cut = 900;
      chunks.add(rest.substring(0, cut).trim());
      rest = rest.substring(cut).trim();
    }
    if (rest.isNotEmpty) chunks.add(rest);

    if (chunks.length == 1) {
      final r = await tts.synthesizeToFile(chunks.first, outFile.path, true);
      final size = await outFile.exists() ? await outFile.length() : 0;
      if (r != 1) {
        _deviceNote = 'synth returned $r';
        return false;
      }
      if (size <= 1000) {
        _deviceNote = 'file too small ($size bytes)';
        return false;
      }
      return true;
    }
    final parts = <File>[];
    for (var i = 0; i < chunks.length; i++) {
      final part = File('${outFile.path}.part$i.wav');
      final r = await tts.synthesizeToFile(chunks[i], part.path, true);
      if (r != 1 || !await part.exists() || await part.length() <= 1000) {
        _deviceNote = 'chunk $i synth returned $r';
        return false;
      }
      parts.add(part);
    }
    final merged = BytesBuilder();
    for (var i = 0; i < parts.length; i++) {
      final bytes = await parts[i].readAsBytes();
      if (bytes.length < 44) return false;
      merged.add(i == 0 ? bytes : bytes.sublist(44));
      try {
        await parts[i].delete();
      } catch (_) {}
    }
    final wav = merged.toBytes();
    if (wav.length < 44) return false;
    // Fix the RIFF/data sizes in the header for the merged length.
    final dataLen = wav.length - 44;
    final riffLen = 36 + dataLen;
    wav[4] = riffLen & 0xFF;
    wav[5] = (riffLen >> 8) & 0xFF;
    wav[6] = (riffLen >> 16) & 0xFF;
    wav[7] = (riffLen >> 24) & 0xFF;
    wav[40] = dataLen & 0xFF;
    wav[41] = (dataLen >> 8) & 0xFF;
    wav[42] = (dataLen >> 16) & 0xFF;
    wav[43] = (dataLen >> 24) & 0xFF;
    await outFile.writeAsBytes(wav);
    return await outFile.length() > 1000;
  }

  // ---------- Offline Piper voices (bundled, cannot be blocked) ----

  static String _piperNote = 'not tried';

  /// Small ffmpeg runner for the pitch step (VideoService has its own;
  /// this file cannot import it — the import would be circular).
  static Future<bool> _runFfmpeg(String command) async {
    try {
      final session = await FFmpegKit.execute(command);
      final rc = await session.getReturnCode();
      return ReturnCode.isSuccess(rc);
    } catch (_) {
      return false;
    }
  }

  /// Shift one synthesised WAV chunk to the preset's pitch while
  /// roughly restoring its duration: asetrate changes pitch AND
  /// speed, aresample brings the rate back, atempo undoes the speed
  /// change. Returns the pitched file, or null on any failure (the
  /// caller then keeps the original WAV — pitch must never fail a
  /// scene).
  static Future<File?> _pitchShiftWav(
      File wav, double pitch, int sampleRate, String outPath) async {
    if (pitch == 1.0) return null;
    final out = File(outPath);
    final newRate = (sampleRate * pitch).round();
    final tempo = (1 / pitch).toStringAsFixed(4);
    final ok = await _runFfmpeg('-y -i "${wav.path}" -af '
        '"asetrate=$newRate,aresample=$sampleRate,atempo=$tempo" '
        '"${out.path}"');
    if (ok && await out.exists() && await out.length() > 1000) {
      return out;
    }
    try {
      if (await out.exists()) await out.delete();
    } catch (_) {}
    return null;
  }

  static bool _piperBindingsReady = false;
  static String? _piperDir;
  static final Map<String, sherpa.OfflineTts> _piperEngines = {};

  static Future<String?> _ensurePiperDir() async {
    if (_piperDir != null) return _piperDir;
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory('${docs.path}/tts_pack');
    // Marker = a model that only exists in the expanded 8-voice
    // pack, so an app upgraded from the old 2-voice pack re-extracts
    // instead of silently keeping the old files.
    final marker = File('${dir.path}/joe.onnx');
    if (!await marker.exists()) {
      final data = await rootBundle.load('assets/tts_pack.zip');
      final bytes = data.buffer.asUint8List();
      final archive = ZipDecoder().decodeBytes(bytes);
      for (final entry in archive) {
        final out = File('${dir.path}/${entry.name}');
        if (entry.isFile) {
          await out.parent.create(recursive: true);
          await out.writeAsBytes(entry.content as List<int>);
        }
      }
    }
    _piperDir = dir.path;
    return _piperDir;
  }

  /// Load (once) and cache the OfflineTts engine for one
  /// (model, tokens) pair. Engines are shared across all chunks and
  /// scenes — never recreated per chunk. Returns null if the pair
  /// cannot be loaded.
  static Future<sherpa.OfflineTts?> _piperEngine(
      String dirPath, String modelFile, String tokensFile) async {
    final key = '$modelFile|$tokensFile';
    final cached = _piperEngines[key];
    if (cached != null) return cached;
    try {
      final config = sherpa.OfflineTtsConfig(
        model: sherpa.OfflineTtsModelConfig(
          vits: sherpa.OfflineTtsVitsModelConfig(
            model: '$dirPath/$modelFile',
            tokens: '$dirPath/$tokensFile',
            dataDir: '$dirPath/espeak-ng-data',
          ),
          numThreads: 2,
        ),
      );
      final engine = sherpa.OfflineTts(config);
      _piperEngines[key] = engine;
      return engine;
    } catch (_) {
      return null;
    }
  }

  static Future<bool> _piperSynth(
      VoicePreset preset, String text, File outFile) async {
    final dirPath = await _ensurePiperDir();
    if (dirPath == null) {
      _piperNote = 'model pack missing';
      return false;
    }
    if (!_piperBindingsReady) {
      sherpa.initBindings();
      _piperBindingsReady = true;
    }
    final male = _maleEdgeNames.contains(preset.edgeName);
    // The preset's assigned real Piper voice; empty assignment (and
    // any missing file, e.g. an older 2-voice pack) falls back to
    // the gender default — ryan (male) / amy (female) + tokens.txt.
    final assigned = preset.piperVoice.trim();
    var modelFile = assigned.isEmpty
        ? (male ? 'ryan.onnx' : 'amy.onnx')
        : '$assigned.onnx';
    var tokensFile = assigned.isEmpty ? 'tokens.txt' : preset.piperTokens;
    if (!await File('$dirPath/$modelFile').exists() ||
        !await File('$dirPath/$tokensFile').exists()) {
      modelFile = male ? 'ryan.onnx' : 'amy.onnx';
      tokensFile = 'tokens.txt';
    }
    var engine = await _piperEngine(dirPath, modelFile, tokensFile);
    if (engine == null && modelFile != (male ? 'ryan.onnx' : 'amy.onnx')) {
      // The assigned pair would not load (broken/incomplete pack):
      // retry once with the gender default pair before giving up.
      engine = await _piperEngine(
          dirPath, male ? 'ryan.onnx' : 'amy.onnx', 'tokens.txt');
    }
    if (engine == null) {
      _piperNote = 'no offline voice could be loaded';
      return false;
    }
    final speed =
        (1.0 + preset.ratePct / 100).clamp(0.6, 1.6).toDouble();
    // Split long scenes; merge the WAV parts afterwards.
    final chunks = <String>[];
    var rest = text;
    while (rest.length > 600) {
      var cut = rest.lastIndexOf('. ', 600);
      if (cut < 150) cut = rest.lastIndexOf(' ', 600);
      if (cut < 150) cut = 600;
      chunks.add(rest.substring(0, cut).trim());
      rest = rest.substring(cut).trim();
    }
    if (rest.isNotEmpty) chunks.add(rest);

    final parts = <File>[];
    for (var i = 0; i < chunks.length; i++) {
      final audio = engine.generate(text: chunks[i], sid: 0, speed: speed);
      if (audio.samples.isEmpty) {
        _piperNote = 'no audio for chunk $i';
        return false;
      }
      final part = File('${outFile.path}.piper$i.wav');
      sherpa.writeWave(
        filename: part.path,
        samples: audio.samples,
        sampleRate: audio.sampleRate,
      );
      if (!await part.exists() || await part.length() <= 1000) {
        _piperNote = 'wav write failed for chunk $i';
        return false;
      }
      // Voice variation: shift this chunk to the preset's pitch
      // BEFORE the merge, so each preset keeps its own character
      // even though only two base voices are bundled. On any failure
      // the unprocessed WAV is used — never fail the scene.
      var effectivePart = part;
      if (preset.piperPitch != 1.0) {
        final pitched = await _pitchShiftWav(
          part,
          preset.piperPitch,
          audio.sampleRate,
          '${outFile.path}.piper$i.pitched.wav',
        );
        if (pitched != null) {
          effectivePart = pitched;
          try {
            await part.delete();
          } catch (_) {}
        }
      }
      parts.add(effectivePart);
    }
    if (parts.length == 1) {
      await parts.first.copy(outFile.path);
      try {
        await parts.first.delete();
      } catch (_) {}
      return true;
    }
    final merged = BytesBuilder();
    for (var i = 0; i < parts.length; i++) {
      final bytes = await parts[i].readAsBytes();
      if (bytes.length < 44) {
        _piperNote = 'bad wav part $i';
        return false;
      }
      merged.add(i == 0 ? bytes : bytes.sublist(44));
      try {
        await parts[i].delete();
      } catch (_) {}
    }
    final wav = merged.toBytes();
    if (wav.length < 44) {
      _piperNote = 'merged wav too small';
      return false;
    }
    final dataLen = wav.length - 44;
    final riffLen = 36 + dataLen;
    wav[4] = riffLen & 0xFF;
    wav[5] = (riffLen >> 8) & 0xFF;
    wav[6] = (riffLen >> 16) & 0xFF;
    wav[7] = (riffLen >> 24) & 0xFF;
    wav[40] = dataLen & 0xFF;
    wav[41] = (dataLen >> 8) & 0xFF;
    wav[42] = (dataLen >> 16) & 0xFF;
    wav[43] = (dataLen >> 24) & 0xFF;
    await outFile.writeAsBytes(wav);
    return await outFile.length() > 1000;
  }
}
