import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// Simple JSON-file based storage for settings and project records.
/// No external database needed for Stage 1.
class Store {
  static Future<Directory> _base() async {
    final dir = await getApplicationDocumentsDirectory();
    final base = Directory('${dir.path}/yt_automation');
    if (!await base.exists()) {
      await base.create(recursive: true);
    }
    return base;
  }

  static Future<File> _file(String name) async {
    final base = await _base();
    return File('${base.path}/$name');
  }

  static Future<Map<String, dynamic>> _readJson(String name) async {
    try {
      final f = await _file(name);
      if (await f.exists()) {
        final text = await f.readAsString();
        if (text.trim().isNotEmpty) {
          return jsonDecode(text) as Map<String, dynamic>;
        }
      }
    } catch (_) {}
    return <String, dynamic>{};
  }

  static Future<void> _writeJson(String name, Map<String, dynamic> data) async {
    final f = await _file(name);
    await f.writeAsString(jsonEncode(data));
  }

  // ---------- Settings ----------

  static Future<bool> welcomeSoundEnabled() async {
    final s = await _readJson('settings.json');
    return (s['welcome_sound'] as bool?) ?? true;
  }

  static Future<void> setWelcomeSoundEnabled(bool value) async {
    final s = await _readJson('settings.json');
    s['welcome_sound'] = value;
    await _writeJson('settings.json', s);
  }

  // ---------- Projects ----------

  static Future<List<Map<String, dynamic>>> listProjects() async {
    final data = await _readJson('projects.json');
    final list = (data['projects'] as List?) ?? <dynamic>[];
    return list
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList()
        .reversed
        .toList();
  }

  static Future<void> addProject(Map<String, dynamic> record) async {
    final data = await _readJson('projects.json');
    final list = (data['projects'] as List?) ?? <dynamic>[];
    list.add(record);
    data['projects'] = list;
    await _writeJson('projects.json', data);
  }

  static Future<Directory> newProjectDir() async {
    final base = await _base();
    final stamp = DateTime.now().millisecondsSinceEpoch.toString();
    final dir = Directory('${base.path}/projects/$stamp');
    await dir.create(recursive: true);
    return dir;
  }
}
