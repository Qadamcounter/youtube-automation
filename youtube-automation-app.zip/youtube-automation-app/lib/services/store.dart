import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// Simple JSON-file based storage for settings and project records.
/// No external database needed for Stage 1.
class Store {
  static Future<Directory> _base() async {
    final dir = await getApplicationDocumentsDirectory();
    final base = Directory('${dir.path}/yt_automation');
    if (!await base.exists()) {
      await base.create(recursive: true);
    }
    return base;
  }

  static Future<File> _file(String name) async {
    final base = await _base();
    return File('${base.path}/$name');
  }

  static Future<Map<String, dynamic>> _readJson(String name) async {
    try {
      final f = await _file(name);
      if (await f.exists()) {
        final text = await f.readAsString();
        if (text.trim().isNotEmpty) {
          return jsonDecode(text) as Map<String, dynamic>;
        }
      }
    } catch (_) {}
    return <String, dynamic>{};
  }

  static Future<void> _writeJson(String name, Map<String, dynamic> data) async {
    final f = await _file(name);
    await f.writeAsString(jsonEncode(data));
  }

  // ---------- Settings ----------

  static Future<bool> welcomeSoundEnabled() async {
    final s = await _readJson('settings.json');
    return (s['welcome_sound'] as bool?) ?? true;
  }

  static Future<void> setWelcomeSoundEnabled(bool value) async {
    final s = await _readJson('settings.json');
    s['welcome_sound'] = value;
    await _writeJson('settings.json', s);
  }

  // ---------- Stock API keys (optional, free keys) ----------

  static Future<String> apiKey(String name) async {
    final s = await _readJson('settings.json');
    return (s['api_$name'] as String?) ?? '';
  }

  static Future<void> setApiKey(String name, String value) async {
    final s = await _readJson('settings.json');
    s['api_$name'] = value.trim();
    await _writeJson('settings.json', s);
  }

  // ---------- Generic settings access (v0.3.0) ----------

  static Future<Map<String, dynamic>> readSettings() =>
      _readJson('settings.json');

  static Future<void> updateSetting(String key, Object? value) async {
    final s = await _readJson('settings.json');
    s[key] = value;
    await _writeJson('settings.json', s);
  }

  /// The app's private base directory (projects, logo, ...).
  static Future<Directory> baseDir() => _base();

  // ---------- Activation code (Buy / Renew screen) ----------

  static Future<String> activationCode() async {
    final s = await _readJson('settings.json');
    return (s['activation_code'] as String?) ?? '';
  }

  static Future<void> setActivationCode(String code) =>
      updateSetting('activation_code', code.trim());

  // ---------- Ads owner settings (saved now, used in Stage 3) ----

  static const List<String> adFormats = [
    'banner',
    'interstitial',
    'native',
    'app_open',
    'rewarded',
  ];

  /// Returns {format: {'enabled': bool, 'unit_id': String}} with
  /// defaults (all OFF, empty IDs) for anything not yet saved.
  static Future<Map<String, Map<String, dynamic>>> adsSettings() async {
    final s = await _readJson('settings.json');
    final raw = (s['ads'] as Map?) ?? {};
    final out = <String, Map<String, dynamic>>{};
    for (final f in adFormats) {
      final m = (raw[f] as Map?) ?? {};
      out[f] = {
        'enabled': (m['enabled'] as bool?) ?? false,
        'unit_id': (m['unit_id'] as String?) ?? '',
      };
    }
    return out;
  }

  static Future<void> setAdFormat(
      String format, bool enabled, String unitId) async {
    final s = await _readJson('settings.json');
    final ads = Map<String, dynamic>.from((s['ads'] as Map?) ?? {});
    ads[format] = {'enabled': enabled, 'unit_id': unitId.trim()};
    s['ads'] = ads;
    await _writeJson('settings.json', s);
  }

  // ---------- Projects ----------

  static Future<List<Map<String, dynamic>>> listProjects() async {
    final data = await _readJson('projects.json');
    final list = (data['projects'] as List?) ?? <dynamic>[];
    return list
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList()
        .reversed
        .toList();
  }

  static Future<void> addProject(Map<String, dynamic> record) async {
    final data = await _readJson('projects.json');
    final list = (data['projects'] as List?) ?? <dynamic>[];
    list.add(record);
    data['projects'] = list;
    await _writeJson('projects.json', data);
  }

  static Future<Directory> newProjectDir() async {
    final base = await _base();
    final stamp = DateTime.now().millisecondsSinceEpoch.toString();
    final dir = Directory('${base.path}/projects/$stamp');
    await dir.create(recursive: true);
    return dir;
  }
}
