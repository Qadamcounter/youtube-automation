import 'dart:io';
import 'dart:math';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:http/http.dart' as http;

import 'edge_tts.dart';
import 'store.dart';

class VideoResult {
  final String videoPath;
  final String srtPath;
  final double durationSec;
  final int sceneCount;
  const VideoResult({
    required this.videoPath,
    required this.srtPath,
    required this.durationSec,
    required this.sceneCount,
  });
}

typedef ProgressFn = void Function(String status, double progress);

/// Shared video pipeline helpers used by both modes.
/// Paper mode: story -> scenes -> free AI images (Pollinations) ->
/// neural voice -> zoom segments -> concat -> captions.
/// Stock mode reuses splitScenes / assembleFinal with real clips.
class VideoService {
  static List<String> splitScenes(String text) {
    final parts = text
        .replaceAll('\r', ' ')
        .split(RegExp(r'(?<=[.!?।۔\n])\s+|\n+'))
        .map((s) => s.trim())
        .where((s) => s.length >= 2)
        .toList();
    if (parts.isEmpty) {
      final t = text.trim();
      return t.isEmpty ? <String>[] : [t];
    }
    // Cap scenes for one render; longer stories continue via render queue.
    return parts.take(30).toList();
  }

  static String two(int n) => n.toString().padLeft(2, '0');

  static String _srtTime(double sec) {
    final ms = ((sec - sec.floor()) * 1000).round();
    final s = sec.floor() % 60;
    final m = (sec.floor() ~/ 60) % 60;
    final h = sec.floor() ~/ 3600;
    return '${two(h)}:${two(m)}:${two(s)},${ms.toString().padLeft(3, '0')}';
  }

  static Future<double> probeDuration(String path) async {
    try {
      final session = await FFprobeKit.getMediaInformation(path);
      final info = session.getMediaInformation();
      final raw = info?.getDuration();
      if (raw == null) return 0;
      return double.tryParse(raw) ?? 0;
    } catch (_) {}
    return 0;
  }

  static Future<bool> runFfmpeg(String command) async {
    final session = await FFmpegKit.execute(command);
    final rc = await session.getReturnCode();
    return ReturnCode.isSuccess(rc);
  }

  /// Fetch one paper-style AI image for a scene (Pollinations, free).
  /// Falls back to a plain paper-coloured frame so a video never breaks.
  static Future<File?> fetchPaperImage(
    String sceneText,
    int index,
    int width,
    int height,
    Directory dir,
  ) async {
    final out = File('${dir.path}/scene-${two(index + 1)}.jpg');
    final prompt = '$sceneText, paper cutout illustration, layered colored '
        'paper craft style, notebook paper background, cute flat paper '
        'characters, soft pastel colors, clean composition, no text, no words';
    final uri = Uri.https('image.pollinations.ai', '/prompt/$prompt', {
      'width': '$width',
      'height': '$height',
      'nologo': 'true',
      'seed': '${index * 7 + 3}',
    });
    try {
      final resp = await http.get(uri).timeout(const Duration(seconds: 60));
      if (resp.statusCode == 200 && resp.bodyBytes.length > 5000) {
        await out.writeAsBytes(resp.bodyBytes);
        return out;
      }
    } catch (_) {}
    final ok = await runFfmpeg(
        '-y -f lavfi -i color=c=0xF3E9D2:s=${width}x$height '
        '-frames:v 1 "${out.path}"');
    return ok ? out : null;
  }

  /// Join finished scene segments, write the .srt, burn captions if
  /// requested, save the project record, and return the result.
  static Future<VideoResult?> assembleFinal({
    required Directory dir,
    required List<String> segPaths,
    required List<String> scenes,
    required List<double> durations,
    required bool captions,
    required String mode,
    required ProgressFn onProgress,
  }) async {
    onProgress('Saare hisse jor rahe hain', 0.92);
    final listFile = File('${dir.path}/list.txt');
    await listFile.writeAsString(segPaths.map((p) => "file '$p'").join('\n'));
    final joined = '${dir.path}/joined.mp4';
    final okJoin = await runFfmpeg(
        '-y -f concat -safe 0 -i "${listFile.path}" -c copy "$joined"');
    if (!okJoin) return null;

    final srt = StringBuffer();
    var cursor = 0.0;
    for (var i = 0; i < scenes.length; i++) {
      final dur = i < durations.length ? durations[i] : 3.0;
      srt.writeln('${i + 1}');
      srt.writeln('${_srtTime(cursor)} --> ${_srtTime(cursor + dur)}');
      srt.writeln(scenes[i]);
      srt.writeln();
      cursor += dur;
    }
    final srtFile = File('${dir.path}/captions.srt');
    await srtFile.writeAsString(srt.toString());

    var finalPath = joined;
    if (captions) {
      onProgress('Captions lag rahe hain', 0.97);
      final withCaps = '${dir.path}/video.mp4';
      final style = 'FontName=DejaVu Sans,FontSize=21,'
          'PrimaryColour=&HFFFFFF&,OutlineColour=&H99000000&,'
          'BorderStyle=1,Outline=2,Shadow=0,Alignment=2,MarginV=30';
      final okCaps = await runFfmpeg('-y -i "$joined" -vf '
          '"subtitles=filename=\'${srtFile.path}\':force_style=\'$style\'" '
          '-c:v libx264 -preset veryfast -crf 21 -c:a copy "$withCaps"');
      if (okCaps) finalPath = withCaps;
      // If caption burn-in fails, plain video + separate .srt is used.
    } else {
      final plain = '${dir.path}/video.mp4';
      await File(joined).copy(plain);
      finalPath = plain;
    }

    onProgress('Tayyar hai', 1.0);
    final first = scenes.isEmpty ? 'Video' : scenes.first;
    final title = first.length > 40 ? '${first.substring(0, 40)}...' : first;
    await Store.addProject({
      'title': title,
      'path': finalPath,
      'srt': srtFile.path,
      'duration': cursor,
      'scenes': scenes.length,
      'mode': mode,
      'created': DateTime.now().toIso8601String(),
    });

    return VideoResult(
      videoPath: finalPath,
      srtPath: srtFile.path,
      durationSec: cursor,
      sceneCount: scenes.length,
    );
  }

  /// Paper Animation mode: images + voice -> video.
  static Future<VideoResult?> buildPaperVideo({
    required String story,
    required VoicePreset voice,
    required String ratio, // '16:9' | '9:16' | '1:1'
    required bool captions,
    required ProgressFn onProgress,
  }) async {
    final scenes = splitScenes(story);
    if (scenes.isEmpty) return null;

    int vw, vh, iw, ih;
    switch (ratio) {
      case '9:16':
        vw = 720; vh = 1280; iw = 720; ih = 1280;
        break;
      case '1:1':
        vw = 720; vh = 720; iw = 960; ih = 960;
        break;
      default:
        vw = 1280; vh = 720; iw = 1280; ih = 720;
    }
    final bigW = (vw * 3) ~/ 2;
    final bigH = (vh * 3) ~/ 2;

    final dir = await Store.newProjectDir();
    final segPaths = <String>[];
    final durations = <double>[];

    for (var i = 0; i < scenes.length; i++) {
      final scene = scenes[i];
      final frac = i / scenes.length;
      onProgress('Scene ${i + 1}/${scenes.length}: image ban rahi hai', frac);
      final img = await fetchPaperImage(scene, i, iw, ih, dir);
      if (img == null) return null;

      onProgress('Scene ${i + 1}/${scenes.length}: awaz ban rahi hai',
          frac + 0.3 / scenes.length);
      final aud = File('${dir.path}/scene-${two(i + 1)}.mp3');
      final okAudio = await TtsService.speakToFile(voice, scene, aud);
      if (!okAudio) return null;

      var dur = await probeDuration(aud.path);
      if (dur <= 0) {
        dur = max(2.0, scene.split(RegExp(r'\s+')).length / 2.4);
      }
      dur += 0.25; // small breathing gap

      onProgress('Scene ${i + 1}/${scenes.length}: video hissa ban raha hai',
          frac + 0.6 / scenes.length);
      final frames = (dur * 30).ceil();
      final seg = '${dir.path}/seg-${two(i + 1)}.mp4';
      final cmd = '-y -i "${img.path}" -i "${aud.path}" -filter_complex '
          '"[0:v]scale=$bigW:$bigH:force_original_aspect_ratio=increase,'
          'crop=$bigW:$bigH,'
          "zoompan=z='min(zoom+0.0008,1.09)':x='iw/2-(iw/zoom/2)':"
          "y='ih/2-(ih/zoom/2)':d=$frames:s=${vw}x$vh:fps=30,"
          'format=yuv420p[v]" '
          '-map "[v]" -map 1:a -c:v libx264 -preset veryfast -crf 21 '
          '-c:a aac -b:a 128k -shortest "$seg"';
      final okSeg = await runFfmpeg(cmd);
      if (!okSeg) return null;
      segPaths.add(seg);
      durations.add(dur);
    }

    return assembleFinal(
      dir: dir,
      segPaths: segPaths,
      scenes: scenes,
      durations: durations,
      captions: captions,
      mode: 'paper',
      onProgress: onProgress,
    );
  }
}
