import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:http/http.dart' as http;

import 'edge_tts.dart';
import 'store.dart';

class VideoResult {
  final String videoPath;
  final String srtPath;
  final double durationSec;
  final int sceneCount;
  final String voiceEngine;
  final String imageSource;
  const VideoResult({
    required this.videoPath,
    required this.srtPath,
    required this.durationSec,
    required this.sceneCount,
    this.voiceEngine = '',
    this.imageSource = '',
  });
}

typedef ProgressFn = void Function(String status, double progress);

/// Shared video pipeline helpers used by both modes.
/// Paper mode: story -> scenes -> free AI images (Pollinations) ->
/// neural voice -> zoom segments -> concat -> captions.
/// Stock mode reuses splitScenes / assembleFinal with real clips.
class VideoService {
  static List<String> splitScenes(String text) {
    final parts = text
        .replaceAll('\r', ' ')
        .split(RegExp(r'(?<=[.!?।۔\n])\s+|\n+'))
        .map((s) => s.trim())
        .where((s) => s.length >= 2)
        .toList();
    if (parts.isEmpty) {
      final t = text.trim();
      return t.isEmpty ? <String>[] : [t];
    }
    // Cap scenes for one render; longer stories continue via render queue.
    return parts.take(30).toList();
  }

  static String two(int n) => n.toString().padLeft(2, '0');
  /// Output dimensions for a ratio + quality pair: [width, height].
  static List<int> dimsFor(String ratio, String quality) {
    final hd = quality == '1080p';
    switch (ratio) {
      case '9:16':
        return hd ? [1080, 1920] : [720, 1280];
      case '1:1':
        return hd ? [1080, 1080] : [720, 720];
      default:
        return hd ? [1920, 1080] : [1280, 720];
    }
  }


  static String _srtTime(double sec) {
    final ms = ((sec - sec.floor()) * 1000).round();
    final s = sec.floor() % 60;
    final m = (sec.floor() ~/ 60) % 60;
    final h = sec.floor() ~/ 3600;
    return '${two(h)}:${two(m)}:${two(s)},${ms.toString().padLeft(3, '0')}';
  }

  static Future<double> probeDuration(String path) async {
    try {
      final session = await FFprobeKit.getMediaInformation(path);
      final info = session.getMediaInformation();
      final raw = info?.getDuration();
      if (raw == null) return 0;
      return double.tryParse(raw) ?? 0;
    } catch (_) {}
    return 0;
  }

  static Future<bool> runFfmpeg(String command) async {
    final session = await FFmpegKit.execute(command);
    final rc = await session.getReturnCode();
    return ReturnCode.isSuccess(rc);
  }

  static const Set<String> _stopwords = {
    'the', 'a', 'an', 'and', 'or', 'but', 'of', 'to', 'in', 'on', 'at',
    'for', 'with', 'was', 'were', 'is', 'are', 'be', 'been', 'he', 'she',
    'it', 'its', 'they', 'them', 'his', 'her', 'their', 'this', 'that',
    'then', 'than', 'when', 'while', 'who', 'what', 'how', 'why', 'all',
    'one', 'two', 'had', 'has', 'have', 'not', 'no', 'yes', 'from', 'by',
    'as', 'into', 'over', 'after', 'before', 'very', 'just', 'also',
  };

  /// Extract up to 3 search keywords from a scene's text.
  static String keywordsFromScene(String scene) {
    final words = scene
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9\s]'), ' ')
        .split(RegExp(r'\s+'))
        .where((w) => w.length >= 4 && !_stopwords.contains(w))
        .toList();
    if (words.isEmpty) return 'nature landscape';
    return words.take(3).join(' ');
  }

  static Future<String?> _wikimediaImageUrl(String query) async {
    try {
      final uri = Uri.https('commons.wikimedia.org', '/w/api.php', {
        'action': 'query',
        'format': 'json',
        'generator': 'search',
        'gsrsearch': query,
        'gsrnamespace': '6',
        'gsrlimit': '6',
        'prop': 'imageinfo',
        'iiprop': 'url|mime',
        'iiurlwidth': '1280',
      });
      final resp = await http.get(uri, headers: {
        'User-Agent': 'YouTubeAutomation/0.2 (contact casenovatv@gmail.com)',
      }).timeout(const Duration(seconds: 30));
      if (resp.statusCode != 200) return null;
      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      final pages = (data['query']?['pages'] as Map?) ?? {};
      for (final page in pages.values) {
        final ii = (page as Map)['imageinfo'] as List?;
        if (ii == null || ii.isEmpty) continue;
        final info = ii.first as Map;
        final mime = '${info['mime'] ?? ''}';
        if (!mime.contains('jpeg') && !mime.contains('png')) continue;
        final thumb = '${info['thumburl'] ?? ''}';
        if (thumb.isNotEmpty) return thumb;
        final url = '${info['url'] ?? ''}';
        if (url.isNotEmpty) return url;
      }
    } catch (_) {}
    return null;
  }

  /// Source of the most recent fetched image: 'AI', 'Photo' or 'Blank'.
  static String lastImageSource = '';

  static Future<String?> _openverseImageUrl(String query) async {
    try {
      final uri = Uri.https('api.openverse.org', '/v1/images/', {
        'q': query,
        'page_size': '5',
        'license_type': 'all',
        'filter_dead': 'false',
      });
      final resp = await http.get(uri, headers: {
        'User-Agent': 'YouTubeAutomation/0.2 (contact casenovatv@gmail.com)',
      }).timeout(const Duration(seconds: 30));
      if (resp.statusCode != 200) return null;
      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      final results = data['results'] as List?;
      if (results == null) return null;
      for (final r in results) {
        final url = '${(r as Map)['url'] ?? ''}';
        if (url.isNotEmpty) return url;
      }
    } catch (_) {}
    return null;
  }

  /// Fetch one paper-style AI image for a scene (Pollinations, free).
  /// Retries politely (the free queue can be slow), then tries a real
  /// photo from Wikimedia Commons, and only as a last resort uses a
  /// plain paper-coloured frame so a video never breaks.
  static Future<File?> fetchPaperImage(
    String sceneText,
    int index,
    int width,
    int height,
    Directory dir,
  ) async {
    final out = File('${dir.path}/scene-${two(index + 1)}.jpg');
    final words = sceneText.trim().split(RegExp(r'\s+'));
    final shortScene =
        words.length > 12 ? words.take(12).join(' ') : sceneText.trim();
    final prompt = '$shortScene, paper cutout illustration, layered colored '
        'paper craft style, notebook paper background, cute flat paper '
        'characters, soft pastel colors, clean composition, no text, no words';
    for (var attempt = 0; attempt < 3; attempt++) {
      try {
        final uri = Uri.parse(
            'https://image.pollinations.ai/prompt/${Uri.encodeComponent(prompt)}'
            '?width=$width&height=$height&nologo=true&model=turbo'
            '&seed=${index * 7 + 3 + attempt * 13}');
        final resp = await http.get(uri).timeout(const Duration(seconds: 90));
        final type = resp.headers['content-type'] ?? '';
        if (resp.statusCode == 200 &&
            resp.bodyBytes.length > 20000 &&
            type.contains('image')) {
          await out.writeAsBytes(resp.bodyBytes);
          // Reject placeholder/error pictures: a real scene image is
          // wide; a service placeholder is not.
          var wideEnough = false;
          try {
            final probe = await FFprobeKit.getMediaInformation(out.path);
            final streams = probe.getMediaInformation()?.getStreams() ?? [];
            for (final st in streams) {
              final w = st.getWidth() ?? 0;
              if (w >= 600) wideEnough = true;
            }
          } catch (_) {}
          if (wideEnough) {
            lastImageSource = 'AI';
            return out;
          }
        }
      } catch (_) {}
    }
    // Fallbacks: a real photo (Openverse, then Wikimedia Commons).
    for (final url in [
      await _openverseImageUrl(keywordsFromScene(sceneText)),
      await _wikimediaImageUrl(keywordsFromScene(sceneText)),
    ]) {
      if (url == null) continue;
      try {
        final resp = await http
            .get(Uri.parse(url))
            .timeout(const Duration(seconds: 45));
        if (resp.statusCode == 200 && resp.bodyBytes.length > 8000) {
          await out.writeAsBytes(resp.bodyBytes);
          lastImageSource = 'Photo';
          return out;
        }
      } catch (_) {}
    }
    final ok = await runFfmpeg(
        '-y -f lavfi -i color=c=0xF3E9D2:s=${width}x$height '
        '-frames:v 1 "${out.path}"');
    if (ok) lastImageSource = 'Blank';
    return ok ? out : null;
  }

  /// Join finished scene segments, write the .srt, burn captions if
  /// requested, save the project record, and return the result.
  static Future<VideoResult?> assembleFinal({
    required Directory dir,
    required List<String> segPaths,
    required List<String> scenes,
    required List<double> durations,
    required bool captions,
    required String mode,
    String voiceEngine = '',
    String imageSource = '',
    File? musicFile,
    double musicVolume = 0,
    bool autoDuck = true,
    required ProgressFn onProgress,
  }) async {
    onProgress('Joining all parts', 0.92);
    final listFile = File('${dir.path}/list.txt');
    await listFile.writeAsString(segPaths.map((p) => "file '$p'").join('\n'));
    final joined = '${dir.path}/joined.mp4';
    final okJoin = await runFfmpeg(
        '-y -f concat -safe 0 -i "${listFile.path}" -c copy "$joined"');
    if (!okJoin) return null;

    final srt = StringBuffer();
    var cursor = 0.0;
    for (var i = 0; i < scenes.length; i++) {
      final dur = i < durations.length ? durations[i] : 3.0;
      srt.writeln('${i + 1}');
      srt.writeln('${_srtTime(cursor)} --> ${_srtTime(cursor + dur)}');
      srt.writeln(scenes[i]);
      srt.writeln();
      cursor += dur;
    }
    final srtFile = File('${dir.path}/captions.srt');
    await srtFile.writeAsString(srt.toString());

    var finalPath = joined;
    if (captions) {
      onProgress('Adding captions', 0.97);
      final withCaps = '${dir.path}/video.mp4';
      final style = 'FontName=DejaVu Sans,FontSize=21,'
          'PrimaryColour=&HFFFFFF&,OutlineColour=&H99000000&,'
          'BorderStyle=1,Outline=2,Shadow=0,Alignment=2,MarginV=30';
      final okCaps = await runFfmpeg('-y -i "$joined" -vf '
          '"subtitles=filename=\'${srtFile.path}\':force_style=\'$style\'" '
          '-c:v libx264 -preset veryfast -crf 21 -c:a copy "$withCaps"');
      if (okCaps) finalPath = withCaps;
      // If caption burn-in fails, plain video + separate .srt is used.
    } else {
      final plain = '${dir.path}/video.mp4';
      await File(joined).copy(plain);
      finalPath = plain;
    }

    if (musicFile != null && musicVolume > 0) {
      onProgress('Adding background music', 0.99);
      final mixed = '${dir.path}/video_final.mp4';
      final vol = musicVolume.toStringAsFixed(2);
      final filter = autoDuck
          ? '[1:a]volume=$vol[music];'
              '[music][0:a]sidechaincompress=threshold=0.03:ratio=8:'
              'attack=200:release=1000[ducked];'
              '[0:a][ducked]amix=inputs=2:duration=first:'
              'dropout_transition=0[aout]'
          : '[1:a]volume=$vol[music];'
              '[0:a][music]amix=inputs=2:duration=first:'
              'dropout_transition=0[aout]';
      final okMix = await runFfmpeg(
          '-y -i "$finalPath" -stream_loop -1 -i "${musicFile.path}" '
          '-filter_complex "$filter" -map 0:v -map "[aout]" '
          '-c:v copy -c:a aac -b:a 160k "$mixed"');
      if (okMix) finalPath = mixed;
    }

    onProgress('Done', 1.0);
    final first = scenes.isEmpty ? 'Video' : scenes.first;
    final title = first.length > 40 ? '${first.substring(0, 40)}...' : first;
    await Store.addProject({
      'title': title,
      'path': finalPath,
      'srt': srtFile.path,
      'duration': cursor,
      'scenes': scenes.length,
      'mode': mode,
      'engine': voiceEngine,
      'image': imageSource,
      'created': DateTime.now().toIso8601String(),
    });

    return VideoResult(
      videoPath: finalPath,
      srtPath: srtFile.path,
      durationSec: cursor,
      sceneCount: scenes.length,
      voiceEngine: voiceEngine,
      imageSource: imageSource,
    );
  }

  /// Paper Animation mode: images + voice -> video.
  static Future<VideoResult?> buildPaperVideo({
    required String story,
    required VoicePreset voice,
    required String ratio, // '16:9' | '9:16' | '1:1'
    required String quality, // '720p' | '1080p'
    required bool captions,
    File? musicFile,
    double musicVolume = 0,
    bool autoDuck = true,
    required ProgressFn onProgress,
  }) async {
    final scenes = splitScenes(story);
    if (scenes.isEmpty) return null;

    final dims = dimsFor(ratio, quality);
    final vw = dims[0];
    final vh = dims[1];
    final iw = vw;
    final ih = vh;
    final bigW = (vw * 3) ~/ 2;
    final bigH = (vh * 3) ~/ 2;

    final dir = await Store.newProjectDir();
    final segPaths = <String>[];
    final durations = <double>[];
    final imgSources = <String>{};

    for (var i = 0; i < scenes.length; i++) {
      final scene = scenes[i];
      final frac = i / scenes.length;
      onProgress('Scene ${i + 1}/${scenes.length}: generating image', frac);
      final img = await fetchPaperImage(scene, i, iw, ih, dir);
      if (img == null) return null;
      imgSources.add(lastImageSource);

      onProgress('Scene ${i + 1}/${scenes.length}: generating voice',
          frac + 0.3 / scenes.length);
      final aud = File('${dir.path}/scene-${two(i + 1)}.mp3');
      final okAudio = await TtsService.speakToFile(voice, scene, aud);
      if (!okAudio) return null;

      var dur = await probeDuration(aud.path);
      if (dur <= 0) {
        dur = max(2.0, scene.split(RegExp(r'\s+')).length / 2.4);
      }
      dur += 0.25; // small breathing gap

      onProgress('Scene ${i + 1}/${scenes.length}: rendering video part',
          frac + 0.6 / scenes.length);
      final frames = (dur * 30).ceil();
      final seg = '${dir.path}/seg-${two(i + 1)}.mp4';
      final cmd = '-y -i "${img.path}" -i "${aud.path}" -filter_complex '
          '"[0:v]scale=$bigW:$bigH:force_original_aspect_ratio=increase,'
          'crop=$bigW:$bigH,'
          "zoompan=z='min(zoom+0.0008,1.09)':x='iw/2-(iw/zoom/2)':"
          "y='ih/2-(ih/zoom/2)':d=$frames:s=${vw}x$vh:fps=30,"
          'format=yuv420p[v]" '
          '-map "[v]" -map 1:a -c:v libx264 -preset veryfast -crf 21 '
          '-c:a aac -b:a 128k -shortest "$seg"';
      final okSeg = await runFfmpeg(cmd);
      if (!okSeg) return null;
      segPaths.add(seg);
      durations.add(dur);
    }

    final imageSummary = imgSources.contains('Blank')
        ? 'Some blank (slow network)'
        : (imgSources.length == 1 && imgSources.first == 'AI'
            ? 'AI generated'
            : 'Photos');
    return assembleFinal(
      dir: dir,
      segPaths: segPaths,
      scenes: scenes,
      durations: durations,
      captions: captions,
      mode: 'paper',
      voiceEngine: TtsService.lastEngine,
      imageSource: imageSummary,
      musicFile: musicFile,
      musicVolume: musicVolume,
      autoDuck: autoDuck,
      onProgress: onProgress,
    );
  }
}
