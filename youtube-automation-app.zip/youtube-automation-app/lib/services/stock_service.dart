import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:http/http.dart' as http;

import 'edge_tts.dart';
import 'store.dart';
import 'video_service.dart';

/// Stock Video mode: story -> scenes -> keywords -> free stock clips
/// (Pexels / Pixabay with free API keys if set in Settings, otherwise
/// Wikimedia Commons which needs no key) -> neural voice -> assembly.
/// If no clip matches a scene, the app falls back to a paper image for
/// that scene and the video still completes.
class StockService {
  static const String _ua =
      'YouTubeAutomation/0.2 (stock search; contact casenovatv@gmail.com)';

  static String keywordsFromScene(String scene) =>
      VideoService.keywordsFromScene(scene);

  static Future<String?> _searchWikimedia(String query) async {
    try {
      final uri = Uri.https('commons.wikimedia.org', '/w/api.php', {
        'action': 'query',
        'format': 'json',
        'generator': 'search',
        'gsrsearch': '$query filetype:video',
        'gsrnamespace': '6',
        'gsrlimit': '6',
        'prop': 'videoinfo',
        'viprop': 'derivatives',
      });
      final resp = await http
          .get(uri, headers: {'User-Agent': _ua})
          .timeout(const Duration(seconds: 30));
      if (resp.statusCode != 200) return null;
      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      final pages = (data['query']?['pages'] as Map?) ?? {};
      String? best;
      var bestWidth = 0;
      for (final page in pages.values) {
        final vi = (page as Map)['videoinfo'] as List?;
        if (vi == null || vi.isEmpty) continue;
        final derivatives = (vi.first as Map)['derivatives'] as List?;
        if (derivatives == null) continue;
        for (final d in derivatives) {
          final m = d as Map;
          final type = '${m['type'] ?? ''}';
          final src = '${m['src'] ?? ''}';
          final width = (m['width'] as num?)?.toInt() ?? 0;
          if (!type.contains('mp4') || src.isEmpty) continue;
          if (width >= 480 && width <= 1280 && width > bestWidth) {
            best = src;
            bestWidth = width;
          } else if (best == null && width > 0) {
            best = src;
            bestWidth = width;
          }
        }
        if (best != null) break;
      }
      return best;
    } catch (_) {
      return null;
    }
  }

  static Future<String?> _searchPexels(String query, String key, bool portrait) async {
    try {
      final uri = Uri.https('api.pexels.com', '/videos/search', {
        'query': query,
        'per_page': '3',
        'orientation': portrait ? 'portrait' : 'landscape',
      });
      final resp = await http.get(uri, headers: {
        'Authorization': key,
        'User-Agent': _ua,
      }).timeout(const Duration(seconds: 30));
      if (resp.statusCode != 200) return null;
      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      final videos = data['videos'] as List?;
      if (videos == null) return null;
      for (final v in videos) {
        final files = (v as Map)['video_files'] as List?;
        if (files == null) continue;
        String? best;
        var bestWidth = 0;
        for (final f in files) {
          final m = f as Map;
          if ('${m['file_type']}' != 'video/mp4') continue;
          final width = (m['width'] as num?)?.toInt() ?? 0;
          final link = '${m['link'] ?? ''}';
          if (link.isEmpty) continue;
          if (width <= 1280 && width > bestWidth) {
            best = link;
            bestWidth = width;
          }
        }
        if (best != null) return best;
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  static Future<String?> _searchPixabay(String query, String key) async {
    try {
      final uri = Uri.https('pixabay.com', '/api/videos/', {
        'key': key,
        'q': query,
        'per_page': '3',
      });
      final resp = await http
          .get(uri, headers: {'User-Agent': _ua})
          .timeout(const Duration(seconds: 30));
      if (resp.statusCode != 200) return null;
      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      final hits = data['hits'] as List?;
      if (hits == null) return null;
      for (final h in hits) {
        final videos = (h as Map)['videos'] as Map?;
        if (videos == null) continue;
        for (final size in ['medium', 'large', 'small']) {
          final entry = videos[size] as Map?;
          final url = '${entry?['url'] ?? ''}';
          if (url.isNotEmpty) return url;
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  static Future<File?> _download(String url, File out) async {
    try {
      final resp = await http
          .get(Uri.parse(url), headers: {'User-Agent': _ua})
          .timeout(const Duration(seconds: 120));
      if (resp.statusCode == 200 && resp.bodyBytes.length > 30000) {
        await out.writeAsBytes(resp.bodyBytes);
        return out;
      }
    } catch (_) {}
    return null;
  }

  static Future<VideoResult?> buildStockVideo({
    required String story,
    required VoicePreset voice,
    required String ratio,
    required String quality, // '720p' | '1080p'
    required bool captions,
    File? musicFile,
    double musicVolume = 0,
    bool autoDuck = true,
    File? fontFile,
    required ProgressFn onProgress,
  }) async {
    final scenes = VideoService.splitScenes(story);
    if (scenes.isEmpty) return null;

    final dims = VideoService.dimsFor(ratio, quality);
    final vw = dims[0];
    final vh = dims[1];
    final bigW = (vw * 3) ~/ 2;
    final bigH = (vh * 3) ~/ 2;

    final pexelsKey = await Store.apiKey('pexels');
    final pixabayKey = await Store.apiKey('pixabay');
    final dir = await Store.newProjectDir();
    final segPaths = <String>[];
    final durations = <double>[];

    for (var i = 0; i < scenes.length; i++) {
      final scene = scenes[i];
      final frac = i / scenes.length;
      final tag = VideoService.two(i + 1);

      onProgress('Scene ${i + 1}/${scenes.length}: generating voice', frac);
      final aud = File('${dir.path}/scene-$tag.mp3');
      final okAudio = await TtsService.speakToFile(voice, scene, aud);
      if (!okAudio) return null;
      var dur = await VideoService.probeDuration(aud.path);
      if (dur <= 0) {
        dur = max(2.0, scene.split(RegExp(r'\s+')).length / 2.4);
      }
      dur += 0.25;

      onProgress('Scene ${i + 1}/${scenes.length}: finding stock clip',
          frac + 0.3 / scenes.length);
      final query = keywordsFromScene(scene);
      String? clipUrl;
      if (pexelsKey.isNotEmpty) {
        clipUrl = await _searchPexels(query, pexelsKey, ratio == '9:16');
      }
      if (clipUrl == null && pixabayKey.isNotEmpty) {
        clipUrl = await _searchPixabay(query, pixabayKey);
      }
      clipUrl ??= await _searchWikimedia(query);

      File? clip;
      if (clipUrl != null) {
        clip = await _download(clipUrl, File('${dir.path}/clip-$tag.mp4'));
      }

      onProgress('Scene ${i + 1}/${scenes.length}: rendering video part',
          frac + 0.6 / scenes.length);
      final seg = '${dir.path}/seg-$tag.mp4';
      bool okSeg;
      if (clip != null) {
        okSeg = await VideoService.runFfmpeg(
            '-y -stream_loop -1 -i "${clip.path}" -i "${aud.path}" '
            '-filter_complex "[0:v]scale=$vw:$vh:'
            'force_original_aspect_ratio=increase,crop=$vw:$vh,fps=30,'
            'format=yuv420p[v]" -map "[v]" -map 1:a -c:v libx264 '
            '-preset veryfast -crf 21 -c:a aac -b:a 128k -shortest '
            '-t ${dur.toStringAsFixed(2)} "$seg"');
      } else {
        // No clip found: paper image fallback for this scene.
        final img = await VideoService.fetchPaperImage(scene, i, vw, vh, dir);
        if (img == null) return null;
        final frames = (dur * 30).ceil();
        okSeg = await VideoService.runFfmpeg(
            '-y -i "${img.path}" -i "${aud.path}" -filter_complex '
            '"[0:v]scale=$bigW:$bigH:force_original_aspect_ratio=increase,'
            'crop=$bigW:$bigH,'
            "zoompan=z='min(zoom+0.0008,1.09)':x='iw/2-(iw/zoom/2)':"
            "y='ih/2-(ih/zoom/2)':d=$frames:s=${vw}x$vh:fps=30,"
            'format=yuv420p[v]" '
            '-map "[v]" -map 1:a -c:v libx264 -preset veryfast -crf 21 '
            '-c:a aac -b:a 128k -shortest "$seg"');
      }
      if (!okSeg) return null;
      segPaths.add(seg);
      durations.add(dur);
    }

    return VideoService.assembleFinal(
      dir: dir,
      segPaths: segPaths,
      scenes: scenes,
      durations: durations,
      captions: captions,
      mode: 'stock',
      width: dims[0],
      height: dims[1],
      fontFile: fontFile,
      voiceEngine: TtsService.lastEngine,
      imageSource: 'Stock clips',
      musicFile: musicFile,
      musicVolume: musicVolume,
      autoDuck: autoDuck,
      onProgress: onProgress,
    );
  }
}
