import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'services/edge_tts.dart';
import 'services/stock_service.dart';
import 'services/store.dart';
import 'services/video_service.dart';

const Color kCream = Color(0xFFF7F0E1);
const Color kTeal = Color(0xFF0E7C86);
const Color kDeep = Color(0xFF0B5563);
const Color kOrange = Color(0xFFF07D1A);

@pragma('vm:entry-point')
void startCallback() {
  FlutterForegroundTask.setTaskHandler(KeepAliveTaskHandler());
}

/// Minimal handler: the service itself does no work — its job is to
/// keep the app process alive (with a progress notification) while a
/// video renders, so switching apps or locking the screen does not
/// kill the build.
class KeepAliveTaskHandler extends TaskHandler {
  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {}

  @override
  void onRepeatEvent(DateTime timestamp) {}

  @override
  Future<void> onDestroy(DateTime timestamp, bool isTimeout) async {}
}

void main() {
  FlutterForegroundTask.init(
    androidNotificationOptions: AndroidNotificationOptions(
      channelId: 'yt_automation_build',
      channelName: 'Video building',
      channelDescription: 'Shown while a video is being made.',
      channelImportance: NotificationChannelImportance.LOW,
      priority: NotificationPriority.LOW,
    ),
    iosNotificationOptions: const IOSNotificationOptions(),
    foregroundTaskOptions: ForegroundTaskOptions(
      eventAction: ForegroundTaskEventAction.nothing(),
      autoRunOnBoot: false,
      autoRunOnMyPackageReplaced: false,
      allowWakeLock: true,
      allowWifiLock: true,
    ),
  );
  runApp(const YtAutomationApp());
}

/// Start/stop helpers for the build keep-alive service. Every call is
/// wrapped so a service problem can never break a video build.
Future<void> _startKeepAlive() async {
  try {
    await FlutterForegroundTask.requestNotificationPermission();
    if (!await FlutterForegroundTask.isRunningService) {
      await FlutterForegroundTask.startService(
        serviceId: 4242,
        notificationTitle: 'YouTube Automation',
        notificationText: 'Making your video…',
        callback: startCallback,
      );
    }
  } catch (_) {}
}

Future<void> _updateKeepAlive(String status, double p) async {
  try {
    if (await FlutterForegroundTask.isRunningService) {
      await FlutterForegroundTask.updateService(
        notificationText: '$status ${(p * 100).round()}%',
      );
    }
  } catch (_) {}
}

Future<void> _stopKeepAlive() async {
  try {
    if (await FlutterForegroundTask.isRunningService) {
      await FlutterForegroundTask.stopService();
    }
  } catch (_) {}
}

class YtAutomationApp extends StatelessWidget {
  const YtAutomationApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'YouTube Automation',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: kCream,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kTeal,
          primary: kTeal,
          secondary: kOrange,
          surface: kCream,
        ),
        fontFamily: 'DejaVu Sans',
      ),
      home: const SplashScreen(),
    );
  }
}

// ---------------- Splash with welcome voice ----------------

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final AudioPlayer _player = AudioPlayer();

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    final enabled = await Store.welcomeSoundEnabled();
    if (enabled) {
      try {
        await _player.play(AssetSource('welcome.mp3'));
      } catch (_) {}
    }
    await Future<void>.delayed(const Duration(milliseconds: 2600));
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 110,
              height: 110,
              decoration: const BoxDecoration(
                color: kTeal,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.content_cut,
                  color: Colors.white, size: 56),
            ),
            const SizedBox(height: 24),
            const Text(
              'YouTube Automation',
              style: TextStyle(
                  fontSize: 30, fontWeight: FontWeight.bold, color: kDeep),
            ),
            const SizedBox(height: 8),
            const Text(
              'Creator: Riaz Sahil',
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
            const SizedBox(height: 32),
            const CircularProgressIndicator(color: kOrange),
          ],
        ),
      ),
    );
  }
}

// ---------------- Home ----------------

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Row(
          children: [
            Icon(Icons.content_cut, color: kTeal),
            SizedBox(width: 8),
            Text('YouTube Automation',
                style: TextStyle(color: kDeep, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _ModeCard(
            icon: Icons.movie_creation_outlined,
            title: 'Stock Video',
            subtitle: 'Paste text — the app adds real stock clips by itself',
            color: kTeal,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(
                  builder: (_) => const CreateScreen(mode: 'stock')),
            ),
          ),
          const SizedBox(height: 16),
          _ModeCard(
            icon: Icons.auto_stories_outlined,
            title: 'Paper Animation',
            subtitle: 'Paste text — a paper cartoon video is made by itself',
            color: kOrange,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(
                  builder: (_) => const CreateScreen(mode: 'paper')),
            ),
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                child: _SmallButton(
                  icon: Icons.folder_open,
                  label: 'My Projects',
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const ProjectsScreen()),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SmallButton(
                  icon: Icons.settings,
                  label: 'Settings',
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const SettingsScreen()),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          const Center(
            child: Text('Creator: Riaz Sahil',
                style: TextStyle(color: Colors.black45, fontSize: 13)),
          ),
        ],
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;
  const _ModeCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      elevation: 2,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(icon, color: Colors.white, size: 34),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.bold,
                            color: kDeep)),
                    const SizedBox(height: 4),
                    Text(subtitle,
                        style: const TextStyle(
                            fontSize: 13.5, color: Colors.black54)),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, size: 18, color: kTeal),
            ],
          ),
        ),
      ),
    );
  }
}

class _SmallButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _SmallButton(
      {required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      elevation: 1,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            children: [
              Icon(icon, color: kTeal, size: 28),
              const SizedBox(height: 6),
              Text(label,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, color: kDeep)),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------- Create (Paper Animation) ----------------

class CreateScreen extends StatefulWidget {
  final String mode; // 'paper' | 'stock'
  const CreateScreen({super.key, this.mode = 'paper'});

  @override
  State<CreateScreen> createState() => _CreateScreenState();
}

class _CreateScreenState extends State<CreateScreen> {
  final TextEditingController _story = TextEditingController();
  String _language = 'English';
  VoicePreset? _voice;
  String _ratio = '16:9';
  String _quality = '720p';
  bool _captions = true;
  bool _intro = true;
  bool _outro = true;
  String _music = 'none';
  double _musicVol = 0.35;
  bool _duck = true;
  bool _building = false;
  String _status = '';
  double _progress = 0;

  static const List<String> _languages = ['English', 'Urdu', 'Arabic', 'Hindi'];
  static const List<String> _ratios = ['16:9', '9:16', '1:1'];
  static const List<String> _qualities = ['720p', '1080p'];
  static const List<List<String>> _musicTracks = [
    ['none', 'No Music'],
    ['calm', 'Calm Pad (Soft Ambient)'],
    ['emotional', 'Emotional (River Meditation)'],
    ['spiritual', 'Islamic Ambient (Spiritual, No Vocals)'],
    ['flute', 'Flute (Bansuri Style)'],
    ['piano', 'Soft Piano'],
  ];

  @override
  void initState() {
    super.initState();
    _voice = voicesForLanguage(_language).first;
  }

  @override
  void dispose() {
    _story.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    final text = _story.text.trim();
    if (text.length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please write some story/text first (at least a sentence or two).')),
      );
      return;
    }
    final voice = _voice;
    if (voice == null) return;
    setState(() {
      _building = true;
      _status = 'Shuru ho raha hai';
      _progress = 0;
    });
    void progress(String status, double p) {
      _updateKeepAlive(status, p);
      if (!mounted) return;
      setState(() {
        _status = status;
        _progress = p;
      });
    }
    await _startKeepAlive();

    File? fontFile;
    try {
      final fdata = await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf');
      final ftmp = await getTemporaryDirectory();
      fontFile = File('${ftmp.path}/caption_font.ttf');
      await fontFile.writeAsBytes(fdata.buffer.asUint8List());
    } catch (_) {
      fontFile = null;
    }
    File? musicFile;
    if (_music != 'none') {
      try {
        final data = await rootBundle.load('assets/music/$_music.mp3');
        final tmp = await getTemporaryDirectory();
        musicFile = File('${tmp.path}/bgmusic_$_music.mp3');
        await musicFile.writeAsBytes(data.buffer.asUint8List());
      } catch (_) {
        musicFile = null;
      }
    }
    // Video title for the intro card / thumbnail: the story's first
    // line, trimmed to a sensible length.
    var videoTitle = text.split('\n').first.trim();
    if (videoTitle.length > 60) {
      videoTitle = '${videoTitle.substring(0, 57)}...';
    }
    final result = widget.mode == 'stock'
        ? await StockService.buildStockVideo(
            story: text,
            voice: voice,
            ratio: _ratio,
            quality: _quality,
            captions: _captions,
            musicFile: musicFile,
            musicVolume: _music == 'none' ? 0 : _musicVol,
            autoDuck: _duck,
            fontFile: fontFile,
            addIntro: _intro,
            addOutro: _outro,
            videoTitle: videoTitle,
            onProgress: progress,
          )
        : await VideoService.buildPaperVideo(
            story: text,
            voice: voice,
            ratio: _ratio,
            quality: _quality,
            captions: _captions,
            musicFile: musicFile,
            musicVolume: _music == 'none' ? 0 : _musicVol,
            autoDuck: _duck,
            fontFile: fontFile,
            addIntro: _intro,
            addOutro: _outro,
            videoTitle: videoTitle,
            onProgress: progress,
          );
    await _stopKeepAlive();
    if (!mounted) return;
    setState(() => _building = false);
    if (result == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('The video could not be made. Check your internet and try again.'),
          duration: Duration(seconds: 5),
        ),
      );
      return;
    }
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => ResultScreen(
          videoPath: result.videoPath,
          srtPath: result.srtPath,
          durationSec: result.durationSec,
          sceneCount: result.sceneCount,
          voiceEngine: result.voiceEngine,
          imageSource: result.imageSource,
          voiceError: TtsService.lastError,
          title: videoTitle,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final voices = voicesForLanguage(_language);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: Text(widget.mode == 'stock' ? 'Stock Video' : 'Paper Animation',
            style: const TextStyle(color: kDeep)),
        iconTheme: const IconThemeData(color: kDeep),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Align(
            alignment: Alignment.centerRight,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.auto_awesome, size: 18),
              label: const Text('Write with AI'),
              onPressed: () async {
                final script = await Navigator.of(context).push<String>(
                  MaterialPageRoute(builder: (_) => const AiScriptScreen()),
                );
                if (script != null && script.trim().isNotEmpty) {
                  setState(() => _story.text = script.trim());
                }
              },
            ),
          ),
          const SizedBox(height: 6),
          const Text('Write or paste your story / text here:',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 8),
          TextField(
            controller: _story,
            maxLines: 8,
            minLines: 5,
            decoration: InputDecoration(
              hintText: 'Once upon a time, in a small village...',
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Language',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: _languages.map((lang) {
              final selected = _language == lang;
              return ChoiceChip(
                label: Text(lang),
                selected: selected,
                onSelected: (_) => setState(() {
                  _language = lang;
                  _voice = voicesForLanguage(lang).first;
                }),
              );
            }).toList(),
          ),
          const SizedBox(height: 18),
          const Text('Voice',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
            ),
            child: DropdownButton<VoicePreset>(
              value: _voice,
              isExpanded: true,
              underline: const SizedBox(),
              items: voices
                  .map((v) => DropdownMenuItem(
                        value: v,
                        child: Text(v.label),
                      ))
                  .toList(),
              onChanged: (v) => setState(() => _voice = v),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Video Size',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: _ratios.map((r) {
              final selected = _ratio == r;
              return ChoiceChip(
                label: Text(r),
                selected: selected,
                onSelected: (_) => setState(() => _ratio = r),
              );
            }).toList(),
          ),
          const SizedBox(height: 18),
          const Text('Quality',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: _qualities.map((q) {
              final selected = _quality == q;
              return ChoiceChip(
                label: Text(q),
                selected: selected,
                onSelected: (_) => setState(() => _quality = q),
              );
            }).toList(),
          ),
          const SizedBox(height: 10),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Add captions (subtitles)'),
            value: _captions,
            activeThumbColor: kOrange,
            onChanged: (v) => setState(() => _captions = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Add intro (title card)'),
            value: _intro,
            activeThumbColor: kOrange,
            onChanged: (v) => setState(() => _intro = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Add outro card'),
            subtitle: const Text('“Thanks for watching!” end card'),
            value: _outro,
            activeThumbColor: kOrange,
            onChanged: (v) => setState(() => _outro = v),
          ),
          const SizedBox(height: 6),
          const Text('Background Music',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
            ),
            child: DropdownButton<String>(
              value: _music,
              isExpanded: true,
              underline: const SizedBox(),
              items: _musicTracks
                  .map((t) => DropdownMenuItem(
                        value: t[0],
                        child: Text(t[1]),
                      ))
                  .toList(),
              onChanged: (v) => setState(() => _music = v ?? 'none'),
            ),
          ),
          if (_music != 'none') ...[
            Row(
              children: [
                const Text('Music volume'),
                Expanded(
                  child: Slider(
                    value: _musicVol,
                    min: 0,
                    max: 1,
                    divisions: 20,
                    activeColor: kOrange,
                    label: '${(_musicVol * 100).round()}%',
                    onChanged: (v) => setState(() => _musicVol = v),
                  ),
                ),
                Text('${(_musicVol * 100).round()}%'),
              ],
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Lower music under the voice (auto-duck)'),
              value: _duck,
              activeThumbColor: kOrange,
              onChanged: (v) => setState(() => _duck = v),
            ),
          ],
          const SizedBox(height: 14),
          if (_building) ...[
            LinearProgressIndicator(value: _progress, color: kOrange),
            const SizedBox(height: 10),
            Text(_status, style: const TextStyle(color: kDeep)),
            const SizedBox(height: 6),
            const Text(
              'Your video is being made — please do not close the app. Longer stories take more time.',
              style: TextStyle(fontSize: 12.5, color: Colors.black54),
            ),
          ] else
            SizedBox(
              height: 54,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: kOrange,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: _create,
                child: const Text('Create Video',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ),
        ],
      ),
    );
  }
}

// ---------------- Result ----------------

class ResultScreen extends StatelessWidget {
  final String videoPath;
  final String srtPath;
  final double durationSec;
  final int sceneCount;
  final String voiceEngine;
  final String imageSource;
  final String voiceError;
  final String title;
  const ResultScreen({
    super.key,
    required this.videoPath,
    required this.srtPath,
    required this.durationSec,
    required this.sceneCount,
    this.voiceEngine = '',
    this.imageSource = '',
    this.voiceError = '',
    this.title = '',
  });

  String get _durationText {
    final m = durationSec ~/ 60;
    final s = (durationSec % 60).round();
    return m > 0 ? '$m min $s sec' : '$s sec';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Text('Video Ready', style: TextStyle(color: kDeep)),
        iconTheme: const IconThemeData(color: kDeep),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.check_circle, size: 84, color: kTeal),
            const SizedBox(height: 16),
            const Center(
              child: Text('Your video is ready!',
                  style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 10),
            Center(
              child: Text('Scenes: $sceneCount  •  Length: $_durationText',
                  style: const TextStyle(color: Colors.black54)),
            ),
            if (voiceEngine.isNotEmpty) ...[
              const SizedBox(height: 6),
              Center(
                child: Text(
                  voiceEngine == 'Backup'
                      ? 'Voice: Backup (natural voices could not connect)'
                      : 'Voice: $voiceEngine (real human voice)',
                  style: const TextStyle(color: Colors.black54),
                ),
              ),
            ],
            if (imageSource.isNotEmpty) ...[
              const SizedBox(height: 4),
              Center(
                child: Text('Pictures: $imageSource',
                    style: const TextStyle(color: Colors.black54)),
              ),
            ],
            if (voiceError.isNotEmpty) ...[
              const SizedBox(height: 4),
              Center(
                child: Text(
                  'Voice note: $voiceError',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 11, color: Colors.black38),
                ),
              ),
            ],
            const SizedBox(height: 8),
            Center(
              child: Text(
                'File: ${videoPath.split('/').last}\nThe captions file (.srt) is saved with it.',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12.5, color: Colors.black45),
              ),
            ),
            const Spacer(),
            SizedBox(
              height: 52,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: kTeal,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                icon: const Icon(Icons.share),
                label: const Text('Share Video'),
                onPressed: () async {
                  await SharePlus.instance.share(ShareParams(
                    files: [XFile(videoPath)],
                    text: 'Made with YouTube Automation',
                  ));
                },
              ),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              icon: const Icon(Icons.subtitles_outlined),
              label: const Text('Share Captions File (.srt)'),
              onPressed: () async {
                if (await File(srtPath).exists()) {
                  await SharePlus.instance.share(ShareParams(
                    files: [XFile(srtPath)],
                  ));
                }
              },
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              icon: const Icon(Icons.image_outlined),
              label: const Text('Make Thumbnail'),
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => ThumbnailScreen(
                    projectDir: File(videoPath).parent.path,
                    title: title.isNotEmpty ? title : 'My Video',
                  ),
                ));
              },
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: () => Navigator.of(context)
                  .popUntil((route) => route.isFirst),
              child: const Text('Back to Home'),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------- Projects ----------------

class ProjectsScreen extends StatelessWidget {
  const ProjectsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Text('My Projects', style: TextStyle(color: kDeep)),
        iconTheme: const IconThemeData(color: kDeep),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: Store.listProjects(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final projects = snapshot.data!;
          if (projects.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'No projects yet.\nMake your first video with Paper Animation.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black54, fontSize: 15),
                ),
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: projects.length,
            separatorBuilder: (_, _) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final p = projects[i];
              final dur = (p['duration'] as num?)?.toDouble() ?? 0;
              return Material(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                child: ListTile(
                  leading: const Icon(Icons.movie_outlined, color: kTeal),
                  title: Text('${p['title'] ?? 'Video'}',
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(
                      '${p['scenes'] ?? ''} scenes • ${dur.toStringAsFixed(0)} sec'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.image_outlined, color: kTeal),
                        tooltip: 'Make Thumbnail',
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) => ThumbnailScreen(
                              projectDir: File('${p['path']}').parent.path,
                              title: '${p['title'] ?? 'My Video'}',
                            ),
                          ));
                        },
                      ),
                      const Icon(Icons.chevron_right),
                    ],
                  ),
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => ResultScreen(
                        videoPath: '${p['path']}',
                        srtPath: '${p['srt'] ?? ''}',
                        durationSec: dur,
                        sceneCount: (p['scenes'] as num?)?.toInt() ?? 0,
                        voiceEngine: '${p['engine'] ?? ''}',
                        imageSource: '${p['image'] ?? ''}',
                        title: '${p['title'] ?? ''}',
                      ),
                    ));
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// ---------------- Thumbnail Maker ----------------

class ThumbnailScreen extends StatefulWidget {
  final String projectDir;
  final String title;
  const ThumbnailScreen({
    super.key,
    required this.projectDir,
    required this.title,
  });

  @override
  State<ThumbnailScreen> createState() => _ThumbnailScreenState();
}

class _ThumbnailScreenState extends State<ThumbnailScreen> {
  late final TextEditingController _titleCtrl;
  List<File> _images = [];
  int _selected = 0;
  bool _busy = false;
  bool _hasThumb = false;
  int _thumbVersion = 0;

  String get _outPath => '${widget.projectDir}/thumbnail.jpg';

  @override
  void initState() {
    super.initState();
    _titleCtrl = TextEditingController(text: widget.title);
    _scan();
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    super.dispose();
  }

  Future<void> _scan() async {
    final dir = Directory(widget.projectDir);
    final found = <File>[];
    if (await dir.exists()) {
      await for (final e in dir.list()) {
        if (e is File) {
          final name = e.path.split('/').last;
          if (name.startsWith('scene-') && name.endsWith('.jpg')) {
            found.add(e);
          }
        }
      }
    }
    found.sort((a, b) => a.path.compareTo(b.path));
    final has = await File(_outPath).exists();
    if (!mounted) return;
    setState(() {
      _images = found;
      _hasThumb = has;
    });
  }

  Future<File?> _fontFile() async {
    try {
      final data = await rootBundle.load('assets/fonts/DejaVuSans-Bold.ttf');
      final tmp = await getTemporaryDirectory();
      final f = File('${tmp.path}/caption_font.ttf');
      await f.writeAsBytes(data.buffer.asUint8List());
      return f;
    } catch (_) {
      return null;
    }
  }

  Future<void> _make() async {
    final title =
        _titleCtrl.text.trim().isEmpty ? 'My Video' : _titleCtrl.text.trim();
    setState(() => _busy = true);
    final font = await _fontFile();
    var ok = false;
    if (font != null) {
      ok = await VideoService.makeThumbnail(
        title: title,
        outPath: _outPath,
        fontFile: font,
        bgImage: _images.isEmpty ? null : _images[_selected],
      );
    }
    if (!mounted) return;
    setState(() {
      _busy = false;
      if (ok) {
        _hasThumb = true;
        _thumbVersion++;
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(ok
            ? 'Thumbnail saved in this project.'
            : 'The thumbnail could not be made. Please try again.'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Text('Thumbnail Maker', style: TextStyle(color: kDeep)),
        iconTheme: const IconThemeData(color: kDeep),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Thumbnail title',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 8),
          TextField(
            controller: _titleCtrl,
            maxLines: 2,
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Background picture',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 8),
          if (_images.isEmpty)
            const Text(
              'No scene pictures found for this project — a plain paper '
              'background will be used.',
              style: TextStyle(color: Colors.black54),
            )
          else
            SizedBox(
              height: 84,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _images.length,
                separatorBuilder: (_, _) => const SizedBox(width: 8),
                itemBuilder: (context, i) {
                  final selected = i == _selected;
                  return GestureDetector(
                    onTap: () => setState(() => _selected = i),
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: selected ? kOrange : Colors.transparent,
                          width: 3,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.file(
                          _images[i],
                          width: 132,
                          height: 76,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          const SizedBox(height: 18),
          SizedBox(
            height: 52,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: kOrange,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: _busy ? null : _make,
              child: _busy
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Make Thumbnail',
                      style: TextStyle(
                          fontSize: 17, fontWeight: FontWeight.bold)),
            ),
          ),
          if (_hasThumb) ...[
            const SizedBox(height: 20),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.file(
                File(_outPath),
                key: ValueKey('thumb_$_thumbVersion'),
                fit: BoxFit.contain,
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              icon: const Icon(Icons.share),
              label: const Text('Share Thumbnail'),
              onPressed: () async {
                await SharePlus.instance.share(ShareParams(
                  files: [XFile(_outPath)],
                  text: 'Thumbnail made with YouTube Automation',
                ));
              },
            ),
          ],
        ],
      ),
    );
  }
}

// ---------------- AI Script Writer ----------------

class AiScriptScreen extends StatefulWidget {
  const AiScriptScreen({super.key});

  @override
  State<AiScriptScreen> createState() => _AiScriptScreenState();
}

class _AiScriptScreenState extends State<AiScriptScreen> {
  final TextEditingController _topic = TextEditingController();
  int _words = 800;
  bool _busy = false;
  String _error = '';

  static const List<List<dynamic>> _lengths = [
    ['Short', 300],
    ['Medium', 800],
    ['Long', 1500],
  ];

  @override
  void dispose() {
    _topic.dispose();
    super.dispose();
  }

  Future<void> _generate() async {
    final topic = _topic.text.trim();
    if (topic.length < 3) {
      setState(() => _error = 'Please enter a topic first.');
      return;
    }
    setState(() {
      _busy = true;
      _error = '';
    });
    try {
      final prompt = 'Write a plain-text narration script of about '
          '$_words words for a YouTube story video about: $topic. '
          'No headings, no scene numbers, just the story narration.';
      final uri =
          Uri.parse('https://text.pollinations.ai/${Uri.encodeComponent(prompt)}');
      final resp = await http.get(uri).timeout(const Duration(seconds: 90));
      final text = resp.statusCode == 200 ? resp.body.trim() : '';
      if (text.length > 30) {
        if (!mounted) return;
        Navigator.of(context).pop(text);
        return;
      }
      setState(() =>
          _error = 'Could not write the script. Please try again.');
    } catch (_) {
      setState(() => _error =
          'Could not write the script. Check your internet and try again.');
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Text('Write with AI', style: TextStyle(color: kDeep)),
        iconTheme: const IconThemeData(color: kDeep),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('What should the story be about?',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 8),
          TextField(
            controller: _topic,
            maxLines: 3,
            decoration: InputDecoration(
              hintText: 'e.g. A poor farmer who finds a hidden treasure',
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Length',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: _lengths.map((l) {
              final words = l[1] as int;
              return ChoiceChip(
                label: Text('${l[0]} (~$words words)'),
                selected: _words == words,
                onSelected: (_) => setState(() => _words = words),
              );
            }).toList(),
          ),
          const SizedBox(height: 22),
          SizedBox(
            height: 52,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: kOrange,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: _busy ? null : _generate,
              child: _busy
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Generate Script',
                      style: TextStyle(
                          fontSize: 17, fontWeight: FontWeight.bold)),
            ),
          ),
          if (_busy) ...[
            const SizedBox(height: 12),
            const Text(
              'Writing your script — this can take up to a minute.',
              style: TextStyle(color: Colors.black54),
            ),
          ],
          if (_error.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(_error, style: const TextStyle(color: Colors.red)),
          ],
        ],
      ),
    );
  }
}

// ---------------- Buy / Renew Plan ----------------

class BuyRenewScreen extends StatefulWidget {
  const BuyRenewScreen({super.key});

  @override
  State<BuyRenewScreen> createState() => _BuyRenewScreenState();
}

class _BuyRenewScreenState extends State<BuyRenewScreen> {
  final TextEditingController _codeCtrl = TextEditingController();
  bool _saved = false;

  static const List<List<String>> _plans = [
    ['Trial', '3 videos • Watermark • Max 1 minute per video'],
    ['Basic', '30 videos/month • Max 5 minutes per video • No watermark'],
    ['Pro', 'More videos • All voices & fonts • Ads off'],
  ];

  @override
  void initState() {
    super.initState();
    Store.activationCode().then((v) {
      if (mounted) _codeCtrl.text = v;
    });
  }

  @override
  void dispose() {
    _codeCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Text('Buy / Renew Plan', style: TextStyle(color: kDeep)),
        iconTheme: const IconThemeData(color: kDeep),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ..._plans.map((p) => Card(
                color: Colors.white,
                elevation: 1,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                child: ListTile(
                  leading: const Icon(Icons.workspace_premium,
                      color: kOrange),
                  title: Text(p[0],
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, color: kDeep)),
                  subtitle: Text(p[1]),
                ),
              )),
          const SizedBox(height: 20),
          const Text('Pay with JazzCash',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('JazzCash: Riaz Hussain — 0303-8542673',
                    style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                        color: kDeep)),
                SizedBox(height: 8),
                Text(
                  'Send the payment to this JazzCash number, then enter '
                  'the activation code you receive in the box below.',
                  style: TextStyle(color: Colors.black54),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const Text('Activation code',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 8),
          TextField(
            controller: _codeCtrl,
            decoration: InputDecoration(
              hintText: 'Enter your activation code',
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 50,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: kTeal,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: () async {
                await Store.setActivationCode(_codeCtrl.text);
                if (!context.mounted) return;
                setState(() => _saved = true);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Code saved.')),
                );
              },
              child: const Text('Save Code',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ),
          if (_saved) ...[
            const SizedBox(height: 10),
            const Text('Code saved.',
                style: TextStyle(color: kTeal, fontWeight: FontWeight.w600)),
          ],
        ],
      ),
    );
  }
}

// ---------------- Ads (Owner) ----------------

class AdsSettingsScreen extends StatefulWidget {
  const AdsSettingsScreen({super.key});

  @override
  State<AdsSettingsScreen> createState() => _AdsSettingsScreenState();
}

class _AdsSettingsScreenState extends State<AdsSettingsScreen> {
  static const List<List<String>> _formats = [
    ['banner', 'Banner'],
    ['interstitial', 'Interstitial'],
    ['native', 'Native'],
    ['app_open', 'App Open'],
    ['rewarded', 'Rewarded'],
  ];

  final Map<String, bool> _enabled = {};
  final Map<String, TextEditingController> _ctrls = {};
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    for (final f in _formats) {
      _enabled[f[0]] = false;
      _ctrls[f[0]] = TextEditingController();
    }
    Store.adsSettings().then((ads) {
      if (!mounted) return;
      setState(() {
        for (final f in _formats) {
          _enabled[f[0]] = ads[f[0]]?['enabled'] == true;
          _ctrls[f[0]]!.text = '${ads[f[0]]?['unit_id'] ?? ''}';
        }
        _loaded = true;
      });
    });
  }

  @override
  void dispose() {
    for (final c in _ctrls.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _saveAll() async {
    for (final f in _formats) {
      await Store.setAdFormat(
          f[0], _enabled[f[0]] ?? false, _ctrls[f[0]]!.text);
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Ad settings saved.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Text('Ads (Owner)', style: TextStyle(color: kDeep)),
        iconTheme: const IconThemeData(color: kDeep),
      ),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text(
                  'Ads go live in Stage 3. These settings are saved now '
                  'and used when ads are switched on.',
                  style: TextStyle(color: Colors.black54),
                ),
                const SizedBox(height: 8),
                ..._formats.map((f) {
                  final key = f[0];
                  return Card(
                    color: Colors.white,
                    elevation: 1,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(8, 4, 12, 12),
                      child: Column(
                        children: [
                          SwitchListTile(
                            contentPadding:
                                const EdgeInsets.only(left: 8),
                            title: Text(f[1],
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: kDeep)),
                            value: _enabled[key] ?? false,
                            activeThumbColor: kOrange,
                            onChanged: (v) async {
                              setState(() => _enabled[key] = v);
                              await Store.setAdFormat(
                                  key, v, _ctrls[key]!.text);
                            },
                          ),
                          TextField(
                            controller: _ctrls[key],
                            decoration: const InputDecoration(
                              labelText: 'Ad Unit ID',
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                            onSubmitted: (_) => _saveAll(),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
                const SizedBox(height: 10),
                SizedBox(
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kTeal,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: _saveAll,
                    child: const Text('Save Ad Settings',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
    );
  }
}

// ---------------- Settings ----------------

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _welcome = true;
  bool _loaded = false;
  final TextEditingController _pexelsCtrl = TextEditingController();
  final TextEditingController _pixabayCtrl = TextEditingController();

  // Video logo state.
  bool _logoEnabled = false;
  String _logoPath = '';
  String _logoPosition = 'br';

  static const List<List<String>> _logoPositions = [
    ['tl', 'Top left'],
    ['tr', 'Top right'],
    ['bl', 'Bottom left'],
    ['br', 'Bottom right'],
  ];

  @override
  void initState() {
    super.initState();
    Store.welcomeSoundEnabled().then((v) {
      if (!mounted) return;
      setState(() {
        _welcome = v;
        _loaded = true;
      });
    });
    Store.apiKey('pexels').then((v) {
      if (mounted) _pexelsCtrl.text = v;
    });
    Store.apiKey('pixabay').then((v) {
      if (mounted) _pixabayCtrl.text = v;
    });
    Store.readSettings().then((s) {
      if (!mounted) return;
      setState(() {
        _logoEnabled = (s['logo_enabled'] as bool?) ?? false;
        _logoPath = (s['logo_path'] as String?) ?? '';
        _logoPosition = (s['logo_position'] as String?) ?? 'br';
      });
    });
  }

  Future<void> _pickLogo() async {
    try {
      final picked =
          await ImagePicker().pickImage(source: ImageSource.gallery);
      if (picked == null) return;
      final base = await Store.baseDir();
      var ext = 'png';
      final dot = picked.path.lastIndexOf('.');
      if (dot >= 0 && dot < picked.path.length - 1) {
        ext = picked.path.substring(dot + 1).toLowerCase();
      }
      final dest = File('${base.path}/logo.$ext');
      await File(picked.path).copy(dest.path);
      await Store.updateSetting('logo_path', dest.path);
      if (!mounted) return;
      setState(() => _logoPath = dest.path);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Logo saved.')),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not pick the logo image.')),
      );
    }
  }

  @override
  void dispose() {
    _pexelsCtrl.dispose();
    _pixabayCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Text('Settings', style: TextStyle(color: kDeep)),
        iconTheme: const IconThemeData(color: kDeep),
      ),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text('Welcome voice'),
            subtitle: const Text(
                'Plays "Welcome to YouTube Automation" when the app opens'),
            value: _loaded ? _welcome : false,
            activeThumbColor: kOrange,
            onChanged: (v) async {
              setState(() => _welcome = v);
              await Store.setWelcomeSoundEnabled(v);
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.workspace_premium, color: kTeal),
            title: const Text('Buy / Renew Plan'),
            subtitle: const Text('Plans, JazzCash payment, activation code'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const BuyRenewScreen()),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.ads_click, color: kTeal),
            title: const Text('Ads (Owner)'),
            subtitle: const Text(
                'Ad formats and Ad Unit IDs. Ads go live in Stage 3.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const AdsSettingsScreen()),
            ),
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Video logo',
                    style: TextStyle(
                        fontWeight: FontWeight.bold, color: kDeep)),
                const SizedBox(height: 4),
                const Text(
                  'Your channel logo, shown in a corner of every video.',
                  style: TextStyle(fontSize: 12.5, color: Colors.black54),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    if (_logoPath.isNotEmpty &&
                        File(_logoPath).existsSync())
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.file(
                          File(_logoPath),
                          width: 56,
                          height: 56,
                          fit: BoxFit.contain,
                        ),
                      )
                    else
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.image_outlined,
                            color: Colors.black38),
                      ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.photo_library_outlined),
                        label: Text(_logoPath.isEmpty
                            ? 'Pick logo image'
                            : 'Change logo image'),
                        onPressed: _pickLogo,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          SwitchListTile(
            title: const Text('Show logo on videos'),
            value: _logoEnabled,
            activeThumbColor: kOrange,
            onChanged: (v) async {
              setState(() => _logoEnabled = v);
              await Store.updateSetting('logo_enabled', v);
            },
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Row(
              children: [
                const Text('Position'),
                const SizedBox(width: 12),
                Expanded(
                  child: Wrap(
                    spacing: 8,
                    children: _logoPositions.map((p) {
                      return ChoiceChip(
                        label: Text(p[1]),
                        selected: _logoPosition == p[0],
                        onSelected: (_) async {
                          setState(() => _logoPosition = p[0]);
                          await Store.updateSetting('logo_position', p[0]);
                        },
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Stock Video API Keys (optional)',
                    style: TextStyle(
                        fontWeight: FontWeight.bold, color: kDeep)),
                const SizedBox(height: 4),
                const Text(
                  'With free keys, Stock mode also fetches clips from '
                  'Pexels/Pixabay. Without keys it uses Wikimedia Commons.',
                  style: TextStyle(fontSize: 12.5, color: Colors.black54),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _pexelsCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Pexels API Key',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _pixabayCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Pixabay API Key',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
                const SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerRight,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: kTeal,
                        foregroundColor: Colors.white),
                    onPressed: () async {
                      await Store.setApiKey('pexels', _pexelsCtrl.text);
                      await Store.setApiKey('pixabay', _pixabayCtrl.text);
                      if (!context.mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Keys saved.')),
                      );
                    },
                    child: const Text('Save Keys'),
                  ),
                ),
              ],
            ),
          ),
          const Divider(),
          const ListTile(
            leading: Icon(Icons.info_outline, color: kTeal),
            title: Text('About'),
            subtitle: Text(
                'YouTube Automation\nCreator: Riaz Sahil\nVersion 0.3.0 (Stage 2)\nMusic: Kevin MacLeod, Audionautix, MusicLFiles (CC BY)'),
          ),
        ],
      ),
    );
  }
}
