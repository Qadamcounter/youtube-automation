import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import 'services/edge_tts.dart';
import 'services/store.dart';
import 'services/video_service.dart';

const Color kCream = Color(0xFFF7F0E1);
const Color kTeal = Color(0xFF0E7C86);
const Color kDeep = Color(0xFF0B5563);
const Color kOrange = Color(0xFFF07D1A);

void main() {
  runApp(const YtAutomationApp());
}

class YtAutomationApp extends StatelessWidget {
  const YtAutomationApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'YouTube Automation',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: kCream,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kTeal,
          primary: kTeal,
          secondary: kOrange,
          surface: kCream,
        ),
        fontFamily: 'DejaVu Sans',
      ),
      home: const SplashScreen(),
    );
  }
}

// ---------------- Splash with welcome voice ----------------

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final AudioPlayer _player = AudioPlayer();

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    final enabled = await Store.welcomeSoundEnabled();
    if (enabled) {
      try {
        await _player.play(AssetSource('welcome.mp3'));
      } catch (_) {}
    }
    await Future<void>.delayed(const Duration(milliseconds: 2600));
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 110,
              height: 110,
              decoration: const BoxDecoration(
                color: kTeal,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.content_cut,
                  color: Colors.white, size: 56),
            ),
            const SizedBox(height: 24),
            const Text(
              'YouTube Automation',
              style: TextStyle(
                  fontSize: 30, fontWeight: FontWeight.bold, color: kDeep),
            ),
            const SizedBox(height: 8),
            const Text(
              'Creator: Riaz Sahil',
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
            const SizedBox(height: 32),
            const CircularProgressIndicator(color: kOrange),
          ],
        ),
      ),
    );
  }
}

// ---------------- Home ----------------

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Row(
          children: [
            Icon(Icons.content_cut, color: kTeal),
            SizedBox(width: 8),
            Text('YouTube Automation',
                style: TextStyle(color: kDeep, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _ModeCard(
            icon: Icons.movie_creation_outlined,
            title: 'Stock Video',
            subtitle: 'Text dein — app khud asal stock clips laga degi',
            color: kTeal,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const StockInfoScreen()),
            ),
          ),
          const SizedBox(height: 16),
          _ModeCard(
            icon: Icons.auto_stories_outlined,
            title: 'Paper Animation',
            subtitle: 'Text dein — paper cartoon video khud ban jayegi',
            color: kOrange,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const CreateScreen()),
            ),
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                child: _SmallButton(
                  icon: Icons.folder_open,
                  label: 'My Projects',
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const ProjectsScreen()),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SmallButton(
                  icon: Icons.settings,
                  label: 'Settings',
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const SettingsScreen()),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          const Center(
            child: Text('Creator: Riaz Sahil',
                style: TextStyle(color: Colors.black45, fontSize: 13)),
          ),
        ],
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;
  const _ModeCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      elevation: 2,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(icon, color: Colors.white, size: 34),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.bold,
                            color: kDeep)),
                    const SizedBox(height: 4),
                    Text(subtitle,
                        style: const TextStyle(
                            fontSize: 13.5, color: Colors.black54)),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, size: 18, color: kTeal),
            ],
          ),
        ),
      ),
    );
  }
}

class _SmallButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _SmallButton(
      {required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      elevation: 1,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            children: [
              Icon(icon, color: kTeal, size: 28),
              const SizedBox(height: 6),
              Text(label,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, color: kDeep)),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------- Stock mode info (Stage 2) ----------------

class StockInfoScreen extends StatelessWidget {
  const StockInfoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Text('Stock Video', style: TextStyle(color: kDeep)),
        iconTheme: const IconThemeData(color: kDeep),
      ),
      body: const Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.movie_creation_outlined, size: 56, color: kTeal),
            SizedBox(height: 16),
            Text(
              'Ye mode Stage 2 mein mukammal ho raha hai.',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 12),
            Text(
              'Phir text dete hi app Pexels, Pixabay, Coverr aur Wikimedia '
              'Commons se copyright-free asal clips khud search karke, '
              'awaz aur captions ke sath poori video bana degi.\n\n'
              'Abhi ke liye Paper Animation mode tayyar hai — '
              'wahan se video bana kar check karein.',
              style: TextStyle(fontSize: 15, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------- Create (Paper Animation) ----------------

class CreateScreen extends StatefulWidget {
  const CreateScreen({super.key});

  @override
  State<CreateScreen> createState() => _CreateScreenState();
}

class _CreateScreenState extends State<CreateScreen> {
  final TextEditingController _story = TextEditingController();
  String _language = 'English';
  VoicePreset? _voice;
  String _ratio = '16:9';
  bool _captions = true;
  bool _building = false;
  String _status = '';
  double _progress = 0;

  static const List<String> _languages = ['English', 'Urdu', 'Arabic', 'Hindi'];
  static const List<String> _ratios = ['16:9', '9:16', '1:1'];

  @override
  void initState() {
    super.initState();
    _voice = voicesForLanguage(_language).first;
  }

  @override
  void dispose() {
    _story.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    final text = _story.text.trim();
    if (text.length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pehle story/text likhein (kam az kam ek do jumlay).')),
      );
      return;
    }
    final voice = _voice;
    if (voice == null) return;
    setState(() {
      _building = true;
      _status = 'Shuru ho raha hai';
      _progress = 0;
    });
    final result = await VideoService.buildPaperVideo(
      story: text,
      voice: voice,
      ratio: _ratio,
      captions: _captions,
      onProgress: (status, progress) {
        if (!mounted) return;
        setState(() {
          _status = status;
          _progress = progress;
        });
      },
    );
    if (!mounted) return;
    setState(() => _building = false);
    if (result == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Video nahi ban saka. Internet check karke dobara koshish karein.'),
          duration: Duration(seconds: 5),
        ),
      );
      return;
    }
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => ResultScreen(
          videoPath: result.videoPath,
          srtPath: result.srtPath,
          durationSec: result.durationSec,
          sceneCount: result.sceneCount,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final voices = voicesForLanguage(_language);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Text('Paper Animation', style: TextStyle(color: kDeep)),
        iconTheme: const IconThemeData(color: kDeep),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Apni story / text yahan likhein ya paste karein:',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 8),
          TextField(
            controller: _story,
            maxLines: 8,
            minLines: 5,
            decoration: InputDecoration(
              hintText: 'Once upon a time, in a small village...',
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Language',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: _languages.map((lang) {
              final selected = _language == lang;
              return ChoiceChip(
                label: Text(lang),
                selected: selected,
                onSelected: (_) => setState(() {
                  _language = lang;
                  _voice = voicesForLanguage(lang).first;
                }),
              );
            }).toList(),
          ),
          const SizedBox(height: 18),
          const Text('Awaz (Voice)',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
            ),
            child: DropdownButton<VoicePreset>(
              value: _voice,
              isExpanded: true,
              underline: const SizedBox(),
              items: voices
                  .map((v) => DropdownMenuItem(
                        value: v,
                        child: Text(v.label),
                      ))
                  .toList(),
              onChanged: (v) => setState(() => _voice = v),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Video Size',
              style: TextStyle(fontWeight: FontWeight.w600, color: kDeep)),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: _ratios.map((r) {
              final selected = _ratio == r;
              return ChoiceChip(
                label: Text(r),
                selected: selected,
                onSelected: (_) => setState(() => _ratio = r),
              );
            }).toList(),
          ),
          const SizedBox(height: 10),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Captions (subtitles) lagayein'),
            value: _captions,
            activeThumbColor: kOrange,
            onChanged: (v) => setState(() => _captions = v),
          ),
          const SizedBox(height: 14),
          if (_building) ...[
            LinearProgressIndicator(value: _progress, color: kOrange),
            const SizedBox(height: 10),
            Text(_status, style: const TextStyle(color: kDeep)),
            const SizedBox(height: 6),
            const Text(
              'Video ban rahi hai — app band na karein. Lambi story par zyada waqt lagega.',
              style: TextStyle(fontSize: 12.5, color: Colors.black54),
            ),
          ] else
            SizedBox(
              height: 54,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: kOrange,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: _create,
                child: const Text('Create Video',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ),
        ],
      ),
    );
  }
}

// ---------------- Result ----------------

class ResultScreen extends StatelessWidget {
  final String videoPath;
  final String srtPath;
  final double durationSec;
  final int sceneCount;
  const ResultScreen({
    super.key,
    required this.videoPath,
    required this.srtPath,
    required this.durationSec,
    required this.sceneCount,
  });

  String get _durationText {
    final m = durationSec ~/ 60;
    final s = (durationSec % 60).round();
    return m > 0 ? '$m min $s sec' : '$s sec';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Text('Video Tayyar', style: TextStyle(color: kDeep)),
        iconTheme: const IconThemeData(color: kDeep),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.check_circle, size: 84, color: kTeal),
            const SizedBox(height: 16),
            const Center(
              child: Text('Aap ki video ban gayi!',
                  style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 10),
            Center(
              child: Text('Scenes: $sceneCount  •  Lambai: $_durationText',
                  style: const TextStyle(color: Colors.black54)),
            ),
            const SizedBox(height: 8),
            Center(
              child: Text(
                'File: ${videoPath.split('/').last}\nCaptions file bhi sath mehfooz hai (.srt).',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12.5, color: Colors.black45),
              ),
            ),
            const Spacer(),
            SizedBox(
              height: 52,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: kTeal,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                icon: const Icon(Icons.share),
                label: const Text('Video Share Karein'),
                onPressed: () async {
                  await SharePlus.instance.share(ShareParams(
                    files: [XFile(videoPath)],
                    text: 'Made with YouTube Automation',
                  ));
                },
              ),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              icon: const Icon(Icons.subtitles_outlined),
              label: const Text('Captions File (.srt) Share Karein'),
              onPressed: () async {
                if (await File(srtPath).exists()) {
                  await SharePlus.instance.share(ShareParams(
                    files: [XFile(srtPath)],
                  ));
                }
              },
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: () => Navigator.of(context)
                  .popUntil((route) => route.isFirst),
              child: const Text('Home Par Wapas'),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------- Projects ----------------

class ProjectsScreen extends StatelessWidget {
  const ProjectsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Text('My Projects', style: TextStyle(color: kDeep)),
        iconTheme: const IconThemeData(color: kDeep),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: Store.listProjects(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final projects = snapshot.data!;
          if (projects.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Abhi koi project nahi.\nPaper Animation se pehli video banayein.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black54, fontSize: 15),
                ),
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: projects.length,
            separatorBuilder: (_, _) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final p = projects[i];
              final dur = (p['duration'] as num?)?.toDouble() ?? 0;
              return Material(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                child: ListTile(
                  leading: const Icon(Icons.movie_outlined, color: kTeal),
                  title: Text('${p['title'] ?? 'Video'}',
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(
                      '${p['scenes'] ?? ''} scenes • ${dur.toStringAsFixed(0)} sec'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => ResultScreen(
                        videoPath: '${p['path']}',
                        srtPath: '${p['srt'] ?? ''}',
                        durationSec: dur,
                        sceneCount: (p['scenes'] as num?)?.toInt() ?? 0,
                      ),
                    ));
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// ---------------- Settings ----------------

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _welcome = true;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    Store.welcomeSoundEnabled().then((v) {
      if (!mounted) return;
      setState(() {
        _welcome = v;
        _loaded = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kCream,
        elevation: 0,
        title: const Text('Settings', style: TextStyle(color: kDeep)),
        iconTheme: const IconThemeData(color: kDeep),
      ),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text('Welcome awaz'),
            subtitle: const Text(
                'App khulne par "Welcome to YouTube Automation" sunai de'),
            value: _loaded ? _welcome : false,
            activeThumbColor: kOrange,
            onChanged: (v) async {
              setState(() => _welcome = v);
              await Store.setWelcomeSoundEnabled(v);
            },
          ),
          const Divider(),
          const ListTile(
            leading: Icon(Icons.ads_click, color: kTeal),
            title: Text('Google Ads'),
            subtitle: Text(
                'Abhi OFF hain. Ads ka control sirf Owner ke paas hai.'),
          ),
          const Divider(),
          const ListTile(
            leading: Icon(Icons.info_outline, color: kTeal),
            title: Text('About'),
            subtitle: Text(
                'YouTube Automation\nCreator: Riaz Sahil\nVersion 0.1.0 (Stage 1 test)'),
          ),
        ],
      ),
    );
  }
}
